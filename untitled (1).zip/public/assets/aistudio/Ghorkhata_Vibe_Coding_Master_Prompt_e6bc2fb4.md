# 🚀 ঘরখাতা (Ghorkhata) — ফুল-স্ট্যাক রিবিল্ড ও ভাইব কোডিং মাস্টার প্রম্পট
**টার্গেট আর্কিটেকচার:** Vite + React 19 (TypeScript) + Tailwind CSS + Dexie.js (Offline IndexedDB) + CapacitorJS (Native Android) + 100% Serverless Google Drive `appDataFolder` Backup

---

## 📌 কীভাবে ব্যবহার করবেন (ব্যবহারের নির্দেশিকা)
আপনার পছন্দের এআই কোডিং এজেন্ট (যেমন: **Cursor, Windsurf, Claude Code, v0, অথবা ChatGPT/Claude**)-এর প্রজেক্ট ওয়ার্কস্পেসে আপনার `Gharkhata--main.zip` ফাইলটি আনজিপ করে ওপেন করুন এবং নিচের **`[START OF AI PROMPT]`** থেকে শেষ পর্যন্ত সম্পূর্ণ অংশটি কপি করে প্রম্পট হিসেবে দিন।

---

## [START OF AI PROMPT]

### Role & Objective
You are an elite Principal Mobile Architect and Senior React/TypeScript Engineer. Your task is to completely refactor and upgrade the existing **"ঘরখাতা" (Ghorkhata)** codebase (`Gharkhata--main`) from its current prototype state (a single monolithic `public/ghorkhata.html` wrapped in a raw Android WebView with broken Next.js API routes) into a **production-grade, 100% serverless, offline-first Native Android application** using **Vite + React (TypeScript) + Tailwind CSS + Dexie.js + CapacitorJS**.

### Why We Are Refactoring the Current Codebase
1. **Broken `/api/*` Routes on Android**: In the current repo, `MainActivity.java` loads `file:///android_asset/index.html` without a Node.js server, causing `fetch('/api/drive')`, `fetch('/api/calendar')`, and `fetch('/api/gemini')` to fail immediately.
2. **Blocked WebView Google OAuth**: Google blocks OAuth popups inside raw Android WebViews (`403 disallowed_useragent`). We must replace this with native Capacitor Google Sign-In ([Capgo Capacitor Social Login Guide](https://capgo.app/blog/how-to-sign-in-with-google-using-capacitor/)) or [Capawesome Google Sign-In](https://capawesome.io/docs/sdks/capacitor/google-sign-in/).
3. **100% Serverless Drive `appDataFolder` Backup**: Instead of cluttering the user's main Google Drive or relying on a backend server, all backups must go directly from the client to Google Drive's hidden **`appDataFolder`** using the `https://www.googleapis.com/auth/drive.appdata` scope and [Google Drive Multipart/Media Upload REST API v3](https://developers.google.com/workspace/drive/api/guides/manage-uploads).
4. **Data Scalability & Legacy Migration**: Replace the 5MB-limited `localStorage` (`ghorkhata:tx:v3` and `ghorkhata:td:v3`) with **Dexie.js (IndexedDB)** while automatically migrating any existing `localStorage` data on first launch.

---

## 🏗️ 1. Target Project Directory Structure

Replace the monolithic HTML/Next.js hybrid with a clean, modular Vite + React + TypeScript + Capacitor architecture:

```text
ghorkhata/
├── .github/
│   └── workflows/
│       └── build-apk.yml                # Updated CI/CD: runs npm build -> npx cap sync android -> Gradle assembleRelease
├── android/                             # Capacitor Android Native Project (package: com.ghorkhata.app)
├── public/
│   └── icons/                           # App icons & assets
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── AppHeader.tsx            # Topbar with month selector, Google sync status dot, & drawer trigger
│   │   │   ├── BottomNav.tsx            # Thumb-friendly bottom bar (হোম, রিপোর্ট, বাকি খাতা, AI সহকারী, সেটিংস) + Center FAB
│   │   │   └── SideDrawer.tsx           # Quick navigation, wallet switcher, backup status, & theme toggle
│   │   ├── home/
│   │   │   ├── HeroSummaryCard.tsx      # Income, Expense, Net Balance, & Spending Progress Bar
│   │   │   ├── WalletStrip.tsx          # Horizontal scrollable strip for Cash, bKash, Nagad, Bank balances
│   │   │   └── CategoryGridList.tsx     # Dynamic list of categories with spending share, item count, & mini progress bar
│   │   ├── transactions/
│   │   │   ├── TransactionModal.tsx     # Add/Edit Modal with Amount, Item Quantity & Unit, Category, Wallet, Status, & AI Quick Fill
│   │   │   ├── QuantityUnitPicker.tsx   # Dedicated Quantity input + quick-select Bengali unit chips (কেজি, লিটার, টি, হালি, প্যাকেট, ইত্যাদি)
│   │   │   ├── CategoryDetailView.tsx   # Date-grouped transaction list with search, filter, Edit, Delete, & batch actions
│   │   │   └── TransactionItemRow.tsx   # Individual item card showing Title, Quantity+Unit badge, Wallet badge, Status, & Edit/Delete menu
│   │   ├── categories/
│   │   │   ├── CategoryManagerModal.tsx # Create, Edit, Reorder, & Delete custom categories
│   │   │   ├── IconPickerGrid.tsx       # Searchable grid of 60+ Lucide icons categorized for household & finance
│   │   │   └── ColorPalettePicker.tsx   # 16 curated emerald/amber/rose/sky/purple color themes ( matching soft bg + deep ink)
│   │   ├── dues/
│   │   │   ├── DuesLedgerView.tsx       # Dedicated 'দোকান বাকি ও ধার-দেনা' tracker (দেনা vs পাওনা)
│   │   │   └── PartialPayModal.tsx      # Record partial repayments & schedule local due-date reminder notifications
│   │   ├── todos/
│   │   │   ├── TodoMarketList.tsx       # Shopping list / To-Do manager with estimated quantity & price
│   │   │   └── ConvertToExpenseModal.tsx# One-tap conversion of checked market list items into an actual expense transaction
│   │   ├── reports/
│   │   │   ├── ReportsView.tsx          # Interactive SVG Donut chart, Daily Bar chart, Top 5 expenses, & Category budget alerts
│   │   │   └── ExportReportModal.tsx    # Export monthly ledger as printable Bengali PDF or Excel/CSV file
│   │   ├── ai/
│   │   │   └── GeminiAssistantView.tsx  # Direct client-side Gemini AI financial advisor & natural Bengali expense parser
│   │   └── settings/
│   │       ├── SyncBackupView.tsx       # Google Sign-In, 1-Click Drive AppData Backup/Restore, & Local JSON Export/Import
│   │       └── AppSettingsView.tsx      # Custom Categories, Wallets, Monthly Budget Limits, Gemini API Key, & PIN Lock
│   ├── db/
│   │   ├── database.ts                  # Dexie.js database instance, tables, & versioned schema
│   │   ├── seedData.ts                  # Default Bengali categories, default wallets, & legacy localStorage migrator
│   │   └── repositories.ts              # Clean CRUD helpers for Transactions, Categories, Wallets, Dues, Todos, & Budgets
│   ├── services/
│   │   ├── googleAuthService.ts         # Native Capacitor Google Auth + Web GIS fallback
│   │   ├── driveAppDataService.ts       # 100% Serverless Google Drive v3 REST API targeting 'appDataFolder'
│   │   ├── geminiClientService.ts       # Client-side @google/genai integration + offline Bengali regex parser fallback
│   │   └── notificationService.ts       # @capacitor/local-notifications for offline bill & shop due reminders
│   ├── types/
│   │   └── index.ts                     # Strict TypeScript interfaces for all entities
│   ├── utils/
│   │   ├── bnFormat.ts                  # Bengali digits (০-৯), Taka formatting (৳), Bengali months, & shade generator
│   │   └── soundHaptics.ts              # Subtle haptic feedback on transaction save/delete
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css                        # Tailwind imports + custom design variables (--paper, --emerald, Hind Siliguri)
├── capacitor.config.ts
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🎨 2. Design System & Aesthetic Preservation

Preserve and elevate the warm, tactile Bengali ledger aesthetic from the original `ghorkhata.html`:
- **Typography**: `'Hind Siliguri', 'Noto Sans Bengali', system-ui, sans-serif`.
- **Color Tokens**:
  - `--paper`: `#f6f3ec` (Warm ledger paper background with subtle radial emerald/amber gradients)
  - `--card`: `#ffffff`
  - `--ink`: `#1c2420`, `--ink-soft`: `#5c6660`, `--ink-faint`: `#98a29b`
  - `--emerald`: `#0b8a5f`, `--emerald-deep`: `#04382b`, `--emerald-light`: `#ddf3e9`
  - `--amber`: `#d98324`, `--amber-light`: `#fdf1df`
  - `--rose`: `#d43d51`, `--rose-light`: `#fde7ea`
  - `--sky`: `#0f74a8`
- **Dark Mode Support**: Provide a clean Dark Mode toggle (`#0f1512` paper, `#18221d` card) in Settings.

---

## 🗄️ 3. Complete TypeScript Data Models (`src/types/index.ts`)

Implement the following strict TypeScript schema:

```typescript
export type CategoryType = 'income' | 'expense' | 'dues' | 'todo';

export interface Category {
  id: string;
  name: string;           // যেমন: "বাজার সদাই", "মাসিক বিল", "মাছ ও মাংস"
  type: CategoryType;
  color: string;          // Hex color, e.g., "#d96a1a"
  bgLight: string;        // Soft tint hex, e.g., "#fcecdd"
  icon: string;           // Lucide icon key, e.g., "ShoppingBasket", "Store", "Receipt"
  monthlyBudget?: number; // Optional monthly budget limit in Taka
  sortOrder: number;
  isDefault?: boolean;
}

export type WalletType = 'cash' | 'bkash' | 'nagad' | 'bank' | 'custom';

export interface Wallet {
  id: string;
  name: string;           // যেমন: "নগদ টাকা", "বিকাশ", "নগদ", "ব্যাংক হিসাব"
  type: WalletType;
  initialBalance: number;
  color: string;
  icon: string;
  isDefault?: boolean;
}

export type PaymentStatus = 'paid' | 'baki' | 'pending';

export interface Transaction {
  id: string;
  categoryId: string;
  walletId: string;       // Default: 'cash'
  title: string;          // বিবরণ (যেমন: "মিনিকেট চাল", "গরুর মাংস")
  amount: number;         // টাকার পরিমাণ (যেমন: 1450)
  quantity?: number;      // বস্তুর পরিমাণ (যেমন: 25, 1.5, 4)
  unit?: string;          // একক (যেমন: "কেজি", "গ্রাম", "লিটার", "টি", "হালি", "প্যাকেট", "বস্তা")
  unitPrice?: number;     // Auto-calculated or optional: amount / quantity
  date: string;           // ISO Date "YYYY-MM-DD"
  status?: PaymentStatus; // 'paid' | 'baki' | 'pending'
  shopOrPerson?: string;  // দোকান বা ব্যক্তির নাম (বিশেষ করে বাকি বা বিলের জন্য)
  dueDate?: string;       // পরিশোধের নির্ধারিত তারিখ (YYYY-MM-DD) for local notification reminder
  note?: string;          // ঐচ্ছিক মন্তব্য
  createdAt: number;
  updatedAt: number;
}

export interface TodoItem {
  id: string;
  title: string;          // যেমন: "সয়াবিন তেল আনতে হবে"
  quantity?: number;      // যেমন: 2
  unit?: string;          // যেমন: "লিটার"
  estimatedAmount?: number; // সম্ভাব্য দাম (ঐচ্ছিক)
  targetCategoryId?: string; // খরচ হিসেবে কনভার্ট করার ডিফল্ট ক্যাটাগরি (যেমন: 'bazar')
  done: boolean;
  dueDate?: string;
  createdAt: string;
}

export interface BackupPayload {
  app: 'ghorkhata';
  schemaVersion: 4;
  exportedAt: string;
  deviceInfo?: string;
  categories: Category[];
  wallets: Wallet[];
  transactions: Transaction[];
  todos: TodoItem[];
  settings: UserSettings;
}

export interface UserSettings {
  id: 'app_settings';
  useBengaliDigits: boolean;
  darkMode: boolean;
  monthlyOverallBudget: number;
  geminiApiKey: string;
  googleClientId: string;
  autoBackupOnChange: boolean;
  lastDriveSync?: string;
  pinCode?: string;
}
```

---

## ✨ 4. Detailed Feature Specifications

### A. টাকার পরিমাণের সাথে বস্তুর পরিমাণ ও একক যুক্ত করা (Item Quantity & Unit System)
1. **In `TransactionModal.tsx` (Add & Edit Mode)**:
   - Right next to or immediately below the **টাকার পরিমাণ (`amount`)** field, build a clean, collapsible or always-visible **"বস্তুর পরিমাণ ও একক" (Quantity & Unit)** row:
     - **পরিমাণ (Quantity Input)**: Numeric/decimal input (`step="any"`, placeholder: `যেমন: ২ বা ১.৫`).Supports typing both English (`2.5`) and Bengali (`২.৫`) numerals (auto-converts Bengali digits to standard numbers on input).
     - **একক (Unit Selector)**: Horizontal scrollable quick-chips + custom text option:
       `['কেজি', 'গ্রাম', 'লিটার', 'মিলি', 'টি', 'হালি', 'ডজন', 'প্যাকেট', 'বস্তা', 'বক্স', 'বোতল', 'বার']`.
   - **Auto Unit-Price Preview**: When both `amount` (e.g., `৳৭০০`) and `quantity` (e.g., `২ কেজি`) are entered, automatically show a subtle helper badge: `দর: ৳৩৫০ / কেজি`.
2. **In Transaction Lists (`TransactionItemRow.tsx`) & Reports**:
   - Display the quantity & unit as a crisp pill badge right beside the item title:
     - Example: **গরুর মাংস** `[১.৫ কেজি]` — **৳১,১২৫**
     - Example: **ডিম** `[৩ হালি]` — **৳১৮০**
   - In Category Detail View, show item-wise aggregation insights (e.g., how much was spent on specific recurring items this month).

### B. আইকন লাইব্রেরিসহ কাস্টম ক্যাটাগরি ম্যানেজার (Custom Categories + Icon & Color Library)
1. **Default Categories Seeded on First Launch**:
   - Keep all 8 original categories (`income` আয়, `bazar` বাজার সদাই, `dues` দোকান বাকি, `monthly` মাসিক বিল, `madrasa` মাদ্রাসা/শিক্ষা খরচ, `medical` ওষুধ/মেডিকেল, `charity` দান-সদকা, `todo` টুডু/বাজারের ফর্দ) and add popular household ones (`transport` যাতায়াত, `fish_meat` মাছ ও মাংস, `snacks` নাস্তা ও অতিথি, `maintenance` ঘর মেরামত).
2. **`CategoryManagerModal.tsx`**:
   - Allow users to **Create New Category**, **Edit Any Category** (name, icon, color, type, monthly budget limit), or **Delete Custom Categories** (if deleting a category that has transactions, prompt to reassign those transactions to another category or delete them).
   - **Built-in Icon Library (`IconPickerGrid.tsx`)**:
     - Include a curated registry of **60+ Lucide React icons** grouped into sections:
       - *বাজার ও খাবার*: `ShoppingBasket`, `ShoppingBag`, `Utensils`, `Apple`, `Beef`, `Fish`, `Coffee`, `Milk`, `Carrot`, `Wheat`, `CookingPot`
       - *ঘরসংসার ও বিল*: `Home`, `Zap`, `Flame`, `Wifi`, `Droplets`, `Phone`, `Tv`, `Wrench`, `Sofa`, `Lightbulb`
       - *শিক্ষা, চিকিৎসা ও পরিবার*: `GraduationCap`, `BookOpen`, `Pill`, `Stethoscope`, `HeartPulse`, `Baby`, `Shirt`, `Gift`, `Users`
       - *যাতায়াত ও যানবাহন*: `Bus`, `Car`, `Bike`, `Fuel`, `Train`, `Plane`
       - *আয়, ব্যাংক ও ব্যবসা*: `Wallet`, `Banknote`, `Landmark`, `PiggyBank`, `Briefcase`, `TrendingUp`, `CreditCard`, `Coins`, `Store`, `Receipt`
       - *ধর্মীয় ও দান*: `HeartHandshake`, `Moon`, `Sparkles`, `HandHeart`
   - **Color Theme Picker (`ColorPalettePicker.tsx`)**:
     - 16 harmonious color pairs (`color` + matching auto-generated `bgLight`).

### C. সম্পূর্ণ এডিট, ডিলিট ও স্ট্যাটাস ম্যানেজমেন্ট (Full CRUD Operations)
1. **Edit Any Entry**:
   - Tapping a transaction row or its Edit button opens `TransactionModal` pre-populated with all existing fields (`title`, `amount`, `quantity`, `unit`, `categoryId`, `walletId`, `date`, `status`, `shopOrPerson`, `dueDate`, `note`).
   - Saving updates the record in Dexie `transactions` table and refreshes the UI immediately.
2. **Delete with Undo / Confirmation**:
   - Provide both a quick Delete confirmation and a 5-second "বাতিল করুন (Undo)" toast notification.
3. **One-Tap Status Toggle (`বাকি` → `পরিশোধিত`)**:
   - For transactions with `status: 'baki'` or `'pending'` (in দোকান বাকি or মাসিক বিল), provide a 1-tap **"পরিশোধ করুন" (Mark as Paid)** button directly on the card.
4. **Shopping List (`টুডু লিস্ট`) to Expense Conversion**:
   - When a user checks off an item in the টুডু লিস্ট (e.g., "চাল ২৫ কেজি"), show a quick **"খরচে যোগ করুন" (Add to Expense)** button that opens the Transaction Modal with the title, quantity, and unit already filled in!

### D. ১০০% সার্ভারলেস Google Drive `appDataFolder` ব্যাকআপ ও রিস্টোর (`src/services/driveAppDataService.ts`)
1. **Zero Backend Requirement**:
   - Delete the old Next.js `/api/drive`, `/api/calendar`, and `/api/gemini` server routes. Everything runs 100% on the client inside Capacitor/Browser.
2. **Authentication (`src/services/googleAuthService.ts`)**:
   - Support Native Android Google Sign-In via Capacitor plugin (`@capawesome/capacitor-google-sign-in` or `@capgo/capacitor-social-login`) AND standard Google Identity Services (`window.google.accounts.oauth2.initTokenClient`) when running in a browser.
   - Request minimal, privacy-friendly scopes:
     `https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile`
   - Why `drive.appdata`? It is a hidden application-specific folder in the user's Google Drive. Users never accidentally delete or corrupt the file, and Google does not require expensive CASA security audits for this scope.
3. **Direct Drive v3 REST API Implementation**:
   - **Find Existing Backup**:
     ```ts
     const listUrl = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='ghorkhata_appdata_v4.json' and trashed=false&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc";
     ```
   - **Upload / Update Backup**:
     - If file exists (`fileId`), perform a direct `PATCH` request to `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media` with `Content-Type: application/json`.
     - If file does not exist, perform a `POST` request to `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart` with metadata `{ name: 'ghorkhata_appdata_v4.json', parents: ['appDataFolder'], mimeType: 'application/json' }`.
   - **Restore Backup**:
     - Download via `GET https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`.
     - Present a confirmation preview showing the backup timestamp, total transactions, and categories, with options to **"মার্জ করুন (Merge with current data)"** or **"রিপ্লেস করুন (Replace all local data)"**.
4. **Offline Local File Backup (Zero-Account Fallback)**:
   - Also provide **"ফোনে ফাইল ডাউনলোড করুন (.json)"** and **"ফাইল থেকে রিস্টোর করুন"** buttons using `@capacitor/filesystem` and `@capacitor/share`, so users can back up to their phone storage or WhatsApp even without a Google account!

### E. অফলাইন রিমাইন্ডার ও নোটিফিকেশন (Replacing Broken Google Calendar Sync)
- Instead of requiring Google Calendar API verification just to set bill reminders, use **`@capacitor/local-notifications`** to schedule native Android push notifications on the phone at 9:00 AM on the `dueDate` of any unpaid bill (`মাসিক বিল`) or shop due (`দোকান বাকি`).
- Also provide an optional **"Google Calendar-এ যোগ করুন"** button on any due item that opens a pre-filled native Google Calendar intent URL (`https://calendar.google.com/calendar/render?action=TEMPLATE&text=...`)—requiring zero API keys or OAuth permissions!

### F. স্মার্ট Gemini AI সহকারী + অফলাইন বাংলা পার্সার (`src/services/geminiClientService.ts`)
1. **Direct Client-Side Gemini SDK**:
   - Use `@google/genai` directly in the client with the user's personal `geminiApiKey` stored in local Settings (`gemini-2.5-flash`).
2. **Smart Natural Bangla Expense Parser (AI + Offline Regex Fallback)**:
   - Whether the user has an API key or is completely **OFFLINE**, the quick input box (`"যেমন: ২ কেজি আলু ১২০ টাকা, ১ লিটার তেল ১৮০ টাকা"`) MUST work:
     - **Online with Gemini Key**: Calls Gemini with structured JSON schema to extract `title`, `amount`, `quantity`, `unit`, `categoryId`, `date`, and `status`.
     - **Offline / No API Key (Built-in Bengali NLP Regex Parser)**: Write a smart deterministic parser in `src/services/geminiClientService.ts` that converts Bengali digits (`০-৯` to `0-9`), detects quantities + units (`(\d+(?:\.\d+)?)\s*(কেজি|গ্রাম|লিটার|টি|হালি|প্যাকেট|বস্তা|ডজন)`), extracts the Taka amount, matches keywords to categories (e.g., `চাল|ডাল|আলু|পেঁয়াজ|তেল|মাছ|মাংস|সবজি` -> `bazar`, `বিদ্যুৎ|গ্যাস|পানি|ভাড়া|ওয়াইফাই` -> `monthly`, `ওষুধ|ডাক্তার` -> `medical`, `বাকি` -> `dues`), and fills the modal fields offline in 0ms!

---

## 🔧 5. Step-by-Step Implementation Plan for the AI

Please execute the refactor in the following exact sequence:

1. **Step 1 — Initialize Vite + React + TypeScript + Tailwind + Capacitor**:
   - Update `package.json` with `vite`, `@vitejs/plugin-react`, `dexie`, `dexie-react-hooks`, `lucide-react`, `@google/genai`, `@capacitor/core`, `@capacitor/cli`, `@capacitor/android`, `@capacitor/local-notifications`, `@capacitor/filesystem`, `@capacitor/share`, and `@capawesome/capacitor-google-sign-in`.
   - Configure `capacitor.config.ts` with `appId: 'com.ghorkhata.app'`, `appName: 'ঘরখাতা'`, and `webDir: 'dist'`.
   - Remove the obsolete Next.js `app/api/*` routes.

2. **Step 2 — Build the Offline Database & Legacy Migrator (`src/db/`)**:
   - Create the Dexie database (`GhorkhataDB`) with tables: `transactions`, `categories`, `wallets`, `todos`, `settings`.
   - Write an automatic migration function that checks `localStorage.getItem('ghorkhata:tx:v3')` and `localStorage.getItem('ghorkhata:td:v3')`, imports any existing user data into Dexie, and seeds the default Bengali categories and wallets (`নগদ ক্যাশ`, `বিকাশ`, `নগদ`, `ব্যাংক`).

3. **Step 3 — Build Utility & Serverless Services (`src/utils/` & `src/services/`)**:
   - Implement `bnFormat.ts` (Bengali digits converter, `bnTaka`, date formatters, Bengali input normalizer).
   - Implement `driveAppDataService.ts` (Full REST v3 multipart upload, media patch, list, and restore from `appDataFolder`).
   - Implement `geminiClientService.ts` (Direct Gemini API call + the offline Bengali regex parser for amount, quantity, unit, and category).
   - Implement `notificationService.ts` (Local notification scheduling for due dates).

4. **Step 4 — Build All Modular UI Components (`src/components/`)**:
   - Build the Home Dashboard, Wallet Strip, Category Grid, Category Detail View (with Search, Filter, Date Grouping, Quantity Badges, Edit & Delete), Transaction Add/Edit Modal (with Quantity, Unit Chips, Unit Price calculator, Wallet selector, and Smart Parser bar), Custom Category Manager (with 60+ Lucide Icon Picker & Color Palette Picker), Reports & Charts View (with PDF/CSV export), Gemini AI Chat View, and Cloud Backup/Settings View.

5. **Step 5 — Update Android Wrapper & GitHub Actions (`android/` & `.github/workflows/build-apk.yml`)**:
   - Update `.github/workflows/build-apk.yml` so that on push/tag, GitHub Actions runs:
     1. `npm ci`
     2. `npm run build` (generates `dist/`)
     3. Syncs `dist/` into `android/app/src/main/assets/` (or `npx cap sync android`)
     4. Builds the signed/installable release APK via Gradle and attaches it to GitHub Releases.

Make sure the code is 100% complete, with zero placeholder comments (`// TODO`), full TypeScript type safety, and polished Bengali UI labels throughout.

## [END OF AI PROMPT]
