package com.example.data.seed

import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.model.WalletItem
import java.util.Locale

object SeedData {
    fun getDefaultCategories(userId: String): List<CategoryItem> = listOf(
        CategoryItem(
            id = "income",
            userId = userId,
            name = "আয়",
            type = "income",
            color = "#0B8A5F",
            bgLight = "#DDF3E9",
            icon = "Wallet",
            sortOrder = 1,
            isDefault = true
        ),
        CategoryItem(
            id = "bazar",
            userId = userId,
            name = "বাজার সদাই",
            type = "expense",
            color = "#D96A1A",
            bgLight = "#FCECDD",
            icon = "ShoppingBasket",
            monthlyBudget = 12000.0,
            sortOrder = 2,
            isDefault = true
        ),
        CategoryItem(
            id = "dues",
            userId = userId,
            name = "দোকান বাকি",
            type = "dues",
            color = "#D43D51",
            bgLight = "#FDE7EA",
            icon = "Store",
            sortOrder = 3,
            isDefault = true
        ),
        CategoryItem(
            id = "monthly",
            userId = userId,
            name = "মাসিক বিল",
            type = "expense",
            color = "#2467C9",
            bgLight = "#E2ECFB",
            icon = "Receipt",
            monthlyBudget = 15000.0,
            sortOrder = 4,
            isDefault = true
        ),
        CategoryItem(
            id = "madrasa",
            userId = userId,
            name = "মাদ্রাসা খরচ",
            type = "expense",
            color = "#7649C9",
            bgLight = "#EDE6FA",
            icon = "GraduationCap",
            sortOrder = 5,
            isDefault = true
        ),
        CategoryItem(
            id = "medical",
            userId = userId,
            name = "ওষুধ / মেডিকেল",
            type = "expense",
            color = "#0F86A8",
            bgLight = "#DEF3F8",
            icon = "Pill",
            sortOrder = 6,
            isDefault = true
        ),
        CategoryItem(
            id = "charity",
            userId = userId,
            name = "দান-সদকা",
            type = "expense",
            color = "#0D9276",
            bgLight = "#DCF2EC",
            icon = "HeartHandshake",
            sortOrder = 7,
            isDefault = true
        ),
        CategoryItem(
            id = "fish_meat",
            userId = userId,
            name = "মাছ ও মাংস",
            type = "expense",
            color = "#E11D48",
            bgLight = "#FFE4E6",
            icon = "Beef",
            sortOrder = 8,
            isDefault = true
        ),
        CategoryItem(
            id = "transport",
            userId = userId,
            name = "যাতায়াত ও ভাড়া",
            type = "expense",
            color = "#059669",
            bgLight = "#D1FAE5",
            icon = "Bus",
            sortOrder = 9,
            isDefault = true
        ),
        CategoryItem(
            id = "todo",
            userId = userId,
            name = "টুডু লিস্ট",
            type = "todo",
            color = "#A8720E",
            bgLight = "#FDF3DD",
            icon = "Check",
            sortOrder = 10,
            isDefault = true
        )
    )

    fun getDefaultWallets(userId: String): List<WalletItem> = listOf(
        WalletItem(
            id = "cash",
            userId = userId,
            name = "নগদ ক্যাশ",
            type = "cash",
            initialBalance = 0.0,
            color = "#0B8A5F",
            icon = "Wallet",
            isDefault = true
        ),
        WalletItem(
            id = "bkash",
            userId = userId,
            name = "বিকাশ",
            type = "bkash",
            initialBalance = 0.0,
            color = "#D12053",
            icon = "Smartphone",
            isDefault = true
        ),
        WalletItem(
            id = "nagad",
            userId = userId,
            name = "নগদ",
            type = "nagad",
            initialBalance = 0.0,
            color = "#F7941D",
            icon = "Smartphone",
            isDefault = true
        ),
        WalletItem(
            id = "bank",
            userId = userId,
            name = "ব্যাংক হিসাব",
            type = "bank",
            initialBalance = 0.0,
            color = "#0F74A8",
            icon = "Landmark",
            isDefault = true
        )
    )

    fun getSampleTransactions(userId: String, monthKey: String): List<TransactionItem> {
        fun d(day: Int) = String.format(Locale.US, "%s-%02d", monthKey, day.coerceIn(1, 28))
        return listOf(
            TransactionItem(userId = userId, categoryId = "income", walletId = "bank", title = "বেতন/মাইনে", amount = 35000.0, date = d(1), status = "paid", note = "মাসিক অফিস বেতন"),
            TransactionItem(userId = userId, categoryId = "income", walletId = "cash", title = "ব্যবসার আয়", amount = 5000.0, date = d(3), status = "paid", note = "দোকান লভ্যাংশ"),
            TransactionItem(userId = userId, categoryId = "income", walletId = "bkash", title = "বিকাশে পাওয়া", amount = 3000.0, date = d(8), status = "paid"),
            TransactionItem(userId = userId, categoryId = "income", walletId = "nagad", title = "নগদে পাওয়া", amount = 1000.0, date = d(10), status = "paid"),
            TransactionItem(userId = userId, categoryId = "bazar", walletId = "cash", title = "মিনিকেট চাল", amount = 1750.0, quantity = 25.0, unit = "কেজি", unitPrice = 70.0, date = d(5), status = "paid", note = "রশিদ ব্র্যান্ড"),
            TransactionItem(userId = userId, categoryId = "bazar", walletId = "cash", title = "মসুর ডাল", amount = 280.0, quantity = 2.0, unit = "কেজি", unitPrice = 140.0, date = d(5), status = "paid"),
            TransactionItem(userId = userId, categoryId = "bazar", walletId = "cash", title = "আলু", amount = 120.0, quantity = 2.0, unit = "কেজি", unitPrice = 60.0, date = d(5), status = "paid"),
            TransactionItem(userId = userId, categoryId = "bazar", walletId = "cash", title = "সয়াবিন তেল", amount = 360.0, quantity = 2.0, unit = "লিটার", unitPrice = 180.0, date = d(9), status = "paid", note = "রূপচাঁদা ২ লিটার বোতল"),
            TransactionItem(userId = userId, categoryId = "fish_meat", walletId = "cash", title = "গরুর মাংস", amount = 1125.0, quantity = 1.5, unit = "কেজি", unitPrice = 750.0, date = d(9), status = "paid", note = "শুক্রবারের বাজার"),
            TransactionItem(userId = userId, categoryId = "fish_meat", walletId = "cash", title = "রুই মাছ", amount = 450.0, quantity = 1.5, unit = "কেজি", unitPrice = 300.0, date = d(11), status = "paid"),
            TransactionItem(userId = userId, categoryId = "bazar", walletId = "cash", title = "ডিম", amount = 180.0, quantity = 3.0, unit = "হালি", unitPrice = 60.0, date = d(11), status = "paid"),
            TransactionItem(userId = userId, categoryId = "monthly", walletId = "bank", title = "বাসা ভাড়া", amount = 8000.0, date = d(5), status = "paid", note = "বাড়িওয়ালাকে পরিশোধিত"),
            TransactionItem(userId = userId, categoryId = "monthly", walletId = "bkash", title = "ওয়াইফাই বিল", amount = 800.0, date = d(10), status = "paid", note = "আম্বর আইটি"),
            TransactionItem(userId = userId, categoryId = "monthly", walletId = "cash", title = "বিদ্যুৎ বিল", amount = 1200.0, date = d(11), status = "baki", shopOrPerson = "ডেসকো প্রিপেইড", note = "চলতি মাসের বিল"),
            TransactionItem(userId = userId, categoryId = "monthly", walletId = "cash", title = "গ্যাস বিল", amount = 1080.0, date = d(11), status = "pending", note = "তিতাস গ্যাস"),
            TransactionItem(userId = userId, categoryId = "dues", walletId = "cash", title = "রহমান স্টোর — মুদি বাজার", amount = 650.0, date = d(4), status = "baki", shopOrPerson = "রহমান স্টোর", note = "মাসের শেষে পরিশোধ"),
            TransactionItem(userId = userId, categoryId = "dues", walletId = "cash", title = "বিসমিল্লাহ ফার্মেসি", amount = 320.0, date = d(7), status = "baki", shopOrPerson = "বিসমিল্লাহ ফার্মেসি", note = "আম্মুর ওষুধ বাবদ"),
            TransactionItem(userId = userId, categoryId = "madrasa", walletId = "cash", title = "মাদ্রাসার মাসিক বেতন", amount = 2000.0, date = d(3), status = "paid", note = "আব্দুল্লাহর বেতন"),
            TransactionItem(userId = userId, categoryId = "madrasa", walletId = "cash", title = "বই ও খাতা কেনা", amount = 450.0, quantity = 6.0, unit = "টি", unitPrice = 75.0, date = d(8), status = "paid"),
            TransactionItem(userId = userId, categoryId = "medical", walletId = "cash", title = "ডাক্তারের ভিজিট ও ওষুধ", amount = 650.0, date = d(10), status = "paid", note = "সিটি হাসপাতাল"),
            TransactionItem(userId = userId, categoryId = "charity", walletId = "cash", title = "মসজিদে জুমার দান", amount = 200.0, date = d(6), status = "paid"),
            TransactionItem(userId = userId, categoryId = "charity", walletId = "cash", title = "এতিমখানায় সদকা", amount = 500.0, date = d(11), status = "paid", note = "মাসিক দান")
        )
    }

    fun getSampleTodos(userId: String): List<TodoItem> = listOf(
        TodoItem(userId = userId, title = "গ্যাস বিল পরিশোধ করতে হবে", estimatedAmount = 1080.0, targetCategoryId = "monthly", done = false),
        TodoItem(userId = userId, title = "পোলাওয়ের চাল আনতে হবে", quantity = 2.0, unit = "কেজি", estimatedAmount = 320.0, targetCategoryId = "bazar", done = false),
        TodoItem(userId = userId, title = "মাদ্রাসার পরীক্ষার ফি দিতে হবে", estimatedAmount = 300.0, targetCategoryId = "madrasa", done = false),
        TodoItem(userId = userId, title = "গুঁড়ো দুধ কিনতে হবে", quantity = 1.0, unit = "প্যাকেট", estimatedAmount = 420.0, targetCategoryId = "bazar", done = true)
    )
}
