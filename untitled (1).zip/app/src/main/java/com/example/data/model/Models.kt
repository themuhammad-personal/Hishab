package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class TransactionItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val categoryId: String = "bazar",
    val walletId: String = "cash",
    val title: String = "",
    val amount: Double = 0.0,
    val quantity: Double? = null,
    val unit: String? = null,
    val unitPrice: Double? = null,
    val date: String = "", // YYYY-MM-DD
    val status: String = "paid", // paid, baki, pending
    val shopOrPerson: String? = null,
    val dueDate: String? = null, // YYYY-MM-DD
    val note: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CategoryItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val type: String = "expense", // income, expense, dues, todo
    val color: String = "#0B8A5F",
    val bgLight: String = "#DDF3E9",
    val icon: String = "ShoppingBasket",
    val monthlyBudget: Double? = null,
    val sortOrder: Int = 0,
    val isDefault: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WalletItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val type: String = "cash", // cash, bkash, nagad, bank, custom
    val initialBalance: Double = 0.0,
    val color: String = "#0B8A5F",
    val icon: String = "Wallet",
    val isDefault: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TodoItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val quantity: Double? = null,
    val unit: String? = null,
    val estimatedAmount: Double? = null,
    val targetCategoryId: String = "bazar",
    val done: Boolean = false,
    val dueDate: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val monthlyOverallBudget: Double = 0.0,
    val useBengaliDigits: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
