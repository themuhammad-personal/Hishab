package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.model.WalletItem
import com.example.data.seed.SeedData
import com.example.util.BnFormat
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType {
    CREATE, UPDATE, DELETE, LIST, GET
}

class GhorkhataRepository(
    private val db: FirebaseFirestore,
    private val context: Context
) {
    companion object {
        private const val TAG = "GhorkhataRepository"

        fun create(context: Context): GhorkhataRepository {
            val dbId = context.applicationContext.getString(R.string.firestore_database_id)
            val firestore = FirebaseFirestore.getInstance(dbId)
            return GhorkhataRepository(firestore, context.applicationContext)
        }
    }

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google")
    }

    private fun handleFirestoreError(e: Exception, op: OperationType, path: String) {
        val code = (e as? FirebaseFirestoreException)?.code?.name ?: "UNKNOWN"
        Log.e(TAG, "FirestoreError [$op] path=$path code=$code msg=${e.message}", e)
    }

    suspend fun checkAndSeedInitialData() {
        val uid = requireUserId()
        try {
            val catColl = db.collection("users").document(uid).collection("categories")
            val existingCats = catColl.get().await()
            val existingIds = existingCats.documents.map { it.id }.toSet()

            val defaultCategories = SeedData.getDefaultCategories(uid)
            val missingCats = defaultCategories.filter { it.id !in existingIds }
            if (missingCats.isNotEmpty()) {
                val batch = db.batch()
                for (cat in missingCats) {
                    val ref = catColl.document(cat.id)
                    val payload = mapOf(
                        "userId" to uid,
                        "name" to cat.name,
                        "type" to cat.type,
                        "color" to cat.color,
                        "bgLight" to cat.bgLight,
                        "icon" to cat.icon,
                        "monthlyBudget" to cat.monthlyBudget,
                        "sortOrder" to cat.sortOrder,
                        "isDefault" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    batch.set(ref, payload)
                }
                batch.commit().await()
            }

            val walletColl = db.collection("users").document(uid).collection("wallets")
            val walletSnap = walletColl.limit(1).get().await()
            if (walletSnap.isEmpty) {
                val batch = db.batch()
                for (w in SeedData.getDefaultWallets(uid)) {
                    val ref = walletColl.document(w.id)
                    val payload = mapOf(
                        "userId" to uid,
                        "name" to w.name,
                        "type" to w.type,
                        "initialBalance" to w.initialBalance,
                        "color" to w.color,
                        "icon" to w.icon,
                        "isDefault" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    batch.set(ref, payload)
                }
                batch.commit().await()
            }

            // Seed initial sample transactions & todos once if user has 0 transactions
            val prefs = context.getSharedPreferences("ghorkhata_prefs", Context.MODE_PRIVATE)
            val alreadySeededSample = prefs.getBoolean("seeded_sample_v2_$uid", false)
            if (!alreadySeededSample) {
                val txColl = db.collection("users").document(uid).collection("transactions")
                val txSnap = txColl.limit(1).get().await()
                if (txSnap.isEmpty) {
                    seedSampleDataNow()
                }
                prefs.edit().putBoolean("seeded_sample_v2_$uid", true).apply()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "users/$uid/seed")
        }
    }

    suspend fun seedSampleDataNow() {
        val uid = requireUserId()
        val txColl = db.collection("users").document(uid).collection("transactions")
        val todoColl = db.collection("users").document(uid).collection("todos")
        val batch = db.batch()

        for (tx in SeedData.getSampleTransactions(uid, BnFormat.currentMonthKey())) {
            val docRef = txColl.document()
            batch.set(
                docRef,
                mapOf(
                    "userId" to uid,
                    "categoryId" to tx.categoryId,
                    "walletId" to tx.walletId,
                    "title" to tx.title,
                    "amount" to tx.amount,
                    "quantity" to tx.quantity,
                    "unit" to tx.unit,
                    "unitPrice" to tx.unitPrice,
                    "date" to tx.date,
                    "status" to tx.status,
                    "shopOrPerson" to tx.shopOrPerson,
                    "dueDate" to tx.dueDate,
                    "note" to tx.note,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        for (todo in SeedData.getSampleTodos(uid)) {
            val docRef = todoColl.document()
            batch.set(
                docRef,
                mapOf(
                    "userId" to uid,
                    "title" to todo.title,
                    "quantity" to todo.quantity,
                    "unit" to todo.unit,
                    "estimatedAmount" to todo.estimatedAmount,
                    "targetCategoryId" to todo.targetCategoryId,
                    "done" to todo.done,
                    "dueDate" to todo.dueDate,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        batch.commit().await()
    }

    suspend fun clearAllUserData() {
        val uid = requireUserId()
        val txColl = db.collection("users").document(uid).collection("transactions")
        val todoColl = db.collection("users").document(uid).collection("todos")
        val txDocs = txColl.get().await()
        val todoDocs = todoColl.get().await()
        val batch = db.batch()
        for (doc in txDocs.documents) {
            batch.delete(doc.reference)
        }
        for (doc in todoDocs.documents) {
            batch.delete(doc.reference)
        }
        batch.commit().await()
    }

    // --- Transactions ---
    fun observeTransactions(): Flow<List<TransactionItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/transactions"
        emitAll(
            db.collection("users").document(uid).collection("transactions")
                .snapshots()
                .map { snap ->
                    snap.toObjects(TransactionItem::class.java)
                        .sortedWith(compareByDescending<TransactionItem> { it.date }.thenByDescending { it.createdAt?.seconds ?: 0L })
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    emit(emptyList())
                }
        )
    }

    suspend fun saveTransaction(tx: TransactionItem): String {
        val uid = requireUserId()
        val coll = db.collection("users").document(uid).collection("transactions")
        val docRef = if (tx.id.isNotBlank()) coll.document(tx.id) else coll.document()
        val payload = mutableMapOf<String, Any?>(
            "userId" to uid,
            "categoryId" to tx.categoryId,
            "walletId" to tx.walletId,
            "title" to tx.title,
            "amount" to tx.amount,
            "quantity" to tx.quantity,
            "unit" to tx.unit,
            "unitPrice" to tx.unitPrice,
            "date" to tx.date.ifBlank { BnFormat.currentDateIso() },
            "status" to tx.status.ifBlank { "paid" },
            "shopOrPerson" to tx.shopOrPerson,
            "dueDate" to tx.dueDate,
            "note" to tx.note,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (tx.id.isBlank()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
        }
        try {
            docRef.set(payload, SetOptions.merge()).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteTransaction(txId: String) {
        if (txId.isBlank()) return
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("transactions").document(txId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
        }
    }

    suspend fun updateTransactionStatus(txId: String, newStatus: String) {
        if (txId.isBlank()) return
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("transactions").document(txId)
        try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    // --- Categories ---
    fun observeCategories(): Flow<List<CategoryItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/categories"
        emitAll(
            db.collection("users").document(uid).collection("categories")
                .snapshots()
                .map { snap ->
                    val list = snap.toObjects(CategoryItem::class.java).sortedBy { it.sortOrder }
                    if (list.isEmpty()) SeedData.getDefaultCategories(uid) else list
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    emit(SeedData.getDefaultCategories(uid))
                }
        )
    }

    suspend fun saveCategory(cat: CategoryItem) {
        val uid = requireUserId()
        val coll = db.collection("users").document(uid).collection("categories")
        val docRef = if (cat.id.isNotBlank()) coll.document(cat.id) else coll.document()
        val payload = mutableMapOf<String, Any?>(
            "userId" to uid,
            "name" to cat.name,
            "type" to cat.type,
            "color" to cat.color,
            "bgLight" to cat.bgLight,
            "icon" to cat.icon,
            "monthlyBudget" to cat.monthlyBudget,
            "sortOrder" to cat.sortOrder,
            "isDefault" to cat.isDefault,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (cat.id.isBlank()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
        }
        docRef.set(payload, SetOptions.merge()).await()
    }

    suspend fun deleteCategory(catId: String) {
        if (catId.isBlank()) return
        val uid = requireUserId()
        db.collection("users").document(uid).collection("categories").document(catId).delete().await()
    }

    // --- Wallets ---
    fun observeWallets(): Flow<List<WalletItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/wallets"
        emitAll(
            db.collection("users").document(uid).collection("wallets")
                .snapshots()
                .map { snap ->
                    val list = snap.toObjects(WalletItem::class.java)
                    if (list.isEmpty()) SeedData.getDefaultWallets(uid) else list
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(SeedData.getDefaultWallets(uid))
                }
        )
    }

    suspend fun saveWallet(w: WalletItem) {
        val uid = requireUserId()
        val coll = db.collection("users").document(uid).collection("wallets")
        val docRef = if (w.id.isNotBlank()) coll.document(w.id) else coll.document()
        val payload = mutableMapOf<String, Any?>(
            "userId" to uid,
            "name" to w.name,
            "type" to w.type,
            "initialBalance" to w.initialBalance,
            "color" to w.color,
            "icon" to w.icon,
            "isDefault" to w.isDefault,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (w.id.isBlank()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
        }
        docRef.set(payload, SetOptions.merge()).await()
    }

    // --- Todos ---
    fun observeTodos(): Flow<List<TodoItem>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users").document(uid).collection("todos")
                .snapshots()
                .map { snap -> snap.toObjects(TodoItem::class.java) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(emptyList())
                }
        )
    }

    suspend fun saveTodo(todo: TodoItem) {
        val uid = requireUserId()
        val coll = db.collection("users").document(uid).collection("todos")
        val docRef = if (todo.id.isNotBlank()) coll.document(todo.id) else coll.document()
        val payload = mutableMapOf<String, Any?>(
            "userId" to uid,
            "title" to todo.title,
            "quantity" to todo.quantity,
            "unit" to todo.unit,
            "estimatedAmount" to todo.estimatedAmount,
            "targetCategoryId" to todo.targetCategoryId,
            "done" to todo.done,
            "dueDate" to todo.dueDate,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (todo.id.isBlank()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
        }
        docRef.set(payload, SetOptions.merge()).await()
    }

    suspend fun deleteTodo(todoId: String) {
        if (todoId.isBlank()) return
        val uid = requireUserId()
        db.collection("users").document(uid).collection("todos").document(todoId).delete().await()
    }

    // --- JSON Export / Import ---
    fun exportBackupJson(
        transactions: List<TransactionItem>,
        categories: List<CategoryItem>,
        wallets: List<WalletItem>,
        todos: List<TodoItem>
    ): String {
        val root = JSONObject()
        root.put("app", "ghorkhata")
        root.put("schemaVersion", 4)
        root.put("exportedAt", BnFormat.currentDateIso())

        val txArr = JSONArray()
        for (tx in transactions) {
            val obj = JSONObject()
            obj.put("id", tx.id)
            obj.put("categoryId", tx.categoryId)
            obj.put("walletId", tx.walletId)
            obj.put("title", tx.title)
            obj.put("amount", tx.amount)
            if (tx.quantity != null) obj.put("quantity", tx.quantity)
            if (tx.unit != null) obj.put("unit", tx.unit)
            if (tx.unitPrice != null) obj.put("unitPrice", tx.unitPrice)
            obj.put("date", tx.date)
            obj.put("status", tx.status)
            if (tx.shopOrPerson != null) obj.put("shopOrPerson", tx.shopOrPerson)
            if (tx.note != null) obj.put("note", tx.note)
            txArr.put(obj)
        }
        root.put("transactions", txArr)

        val tdArr = JSONArray()
        for (td in todos) {
            val obj = JSONObject()
            obj.put("id", td.id)
            obj.put("title", td.title)
            if (td.quantity != null) obj.put("quantity", td.quantity)
            if (td.unit != null) obj.put("unit", td.unit)
            if (td.estimatedAmount != null) obj.put("estimatedAmount", td.estimatedAmount)
            obj.put("targetCategoryId", td.targetCategoryId)
            obj.put("done", td.done)
            tdArr.put(obj)
        }
        root.put("todos", tdArr)
        return root.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Int {
        val uid = requireUserId()
        val root = JSONObject(jsonString)
        val txArr = root.optJSONArray("transactions") ?: JSONArray()
        val tdArr = root.optJSONArray("todos") ?: JSONArray()
        val batch = db.batch()
        var count = 0

        val txColl = db.collection("users").document(uid).collection("transactions")
        for (i in 0 until txArr.length()) {
            val obj = txArr.getJSONObject(i)
            val id = obj.optString("id").takeIf { it.isNotBlank() }
            val ref = if (id != null) txColl.document(id) else txColl.document()
            batch.set(
                ref,
                mapOf(
                    "userId" to uid,
                    "categoryId" to obj.optString("categoryId", "bazar"),
                    "walletId" to obj.optString("walletId", "cash"),
                    "title" to obj.optString("title", "এন্ট্রি"),
                    "amount" to obj.optDouble("amount", 0.0),
                    "quantity" to if (obj.has("quantity")) obj.optDouble("quantity") else null,
                    "unit" to obj.optString("unit").takeIf { it.isNotBlank() },
                    "date" to obj.optString("date", BnFormat.currentDateIso()),
                    "status" to obj.optString("status", "paid"),
                    "shopOrPerson" to obj.optString("shopOrPerson").takeIf { it.isNotBlank() },
                    "note" to obj.optString("note").takeIf { it.isNotBlank() },
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            count++
        }

        val tdColl = db.collection("users").document(uid).collection("todos")
        for (i in 0 until tdArr.length()) {
            val obj = tdArr.getJSONObject(i)
            val id = obj.optString("id").takeIf { it.isNotBlank() }
            val ref = if (id != null) tdColl.document(id) else tdColl.document()
            batch.set(
                ref,
                mapOf(
                    "userId" to uid,
                    "title" to obj.optString("title", "টাস্ক"),
                    "quantity" to if (obj.has("quantity")) obj.optDouble("quantity") else null,
                    "unit" to obj.optString("unit").takeIf { it.isNotBlank() },
                    "estimatedAmount" to if (obj.has("estimatedAmount")) obj.optDouble("estimatedAmount") else null,
                    "targetCategoryId" to obj.optString("targetCategoryId", "bazar"),
                    "done" to obj.optBoolean("done", false),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            count++
        }

        batch.commit().await()
        return count
    }
}
