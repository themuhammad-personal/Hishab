package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.repository.GhorkhataRepository
import com.example.ui.components.AppSettingsView
import com.example.ui.components.AppTopBar
import com.example.ui.components.AuthScreen
import com.example.ui.components.CategoryDetailView
import com.example.ui.components.CategoryManagerModal
import com.example.ui.components.DuesLedgerView
import com.example.ui.components.GeminiAssistantView
import com.example.ui.components.HomeDashboardView
import com.example.ui.components.ReportsView
import com.example.ui.components.TodoMarketListView
import com.example.ui.components.TransactionModal
import com.example.ui.components.attemptAutoSignIn
import com.example.ui.components.signOut
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GhorkhataTheme
import com.example.ui.theme.RoseExpense
import com.example.util.BnFormat
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.recaptcha.RecaptchaAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private const val TAG = "AppCheckInit"
private const val DEBUG_TOKEN_EXTRA = "FIREBASE_APPCHECK_DEBUG_TOKEN"
private const val DEBUG_STORE_PREFIX = "com.google.firebase.appcheck.debug.store."
private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"
private const val RECAPTCHA_SITE_KEY_RES = "recaptcha_site_key"

fun configureAppCheck(context: Context, intent: Intent?) {
    try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }

        if (BuildConfig.DEBUG) {
            val debugToken = intent?.getStringExtra(DEBUG_TOKEN_EXTRA)
            if (!debugToken.isNullOrEmpty()) {
                val persistenceKey = FirebaseApp.getInstance().persistenceKey
                val prefs = context.getSharedPreferences(
                    "$DEBUG_STORE_PREFIX$persistenceKey",
                    Context.MODE_PRIVATE
                )
                prefs.edit()
                    .putString(DEBUG_SECRET_KEY, debugToken)
                    .commit()
                Log.d(TAG, "App Check debug secret configured successfully.")
            } else {
                Log.w(TAG, "No debug token found in Intent extra.")
            }

            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
            Log.d(TAG, "DebugAppCheckProviderFactory installed.")
        } else {
            val resId = context.resources.getIdentifier(RECAPTCHA_SITE_KEY_RES, "string", context.packageName)
            if (resId != 0) {
                val siteKey = context.getString(resId)
                if (siteKey.isNotBlank()) {
                    FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                        RecaptchaAppCheckProviderFactory.getInstance(siteKey)
                    )
                    Log.d(TAG, "RecaptchaAppCheckProviderFactory installed.")
                }
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "Failed to initialize Firebase App Check", e)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure App Check before any Compose UI or Firebase operations
        configureAppCheck(this, intent)

        setContent {
            GhorkhataTheme {
                GhorkhataApp()
            }
        }
    }
}

enum class ScreenDestination {
    HOME,
    CATEGORY_DETAIL,
    REPORTS,
    DUES,
    TODOS,
    AI,
    SETTINGS
}

@Composable
fun GhorkhataApp() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = { currentUser = Firebase.auth.currentUser },
            onUnauthenticated = {},
            scope = scope
        )
    }

    if (currentUser == null) {
        AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        MainScreen(
            currentUserId = currentUser!!.uid,
            onSignOut = {
                signOut(credentialManager, scope) {
                    currentUser = null
                }
            }
        )
    }
}

@Composable
fun MainScreen(
    currentUserId: String,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val repository = remember(currentUserId) { GhorkhataRepository.create(context) }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    var currentScreen by remember { mutableStateOf(ScreenDestination.HOME) }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var currentMonth by remember { mutableStateOf(BnFormat.currentMonthKey()) }

    var showTransactionModal by remember { mutableStateOf(false) }
    var transactionToEdit by remember { mutableStateOf<TransactionItem?>(null) }
    var modalDefaultCategoryId by remember { mutableStateOf<String?>(null) }
    var showCategoryManager by remember { mutableStateOf(false) }

    val transactions by repository.observeTransactions().collectAsState(initial = emptyList())
    val categories by repository.observeCategories().collectAsState(initial = emptyList())
    val wallets by repository.observeWallets().collectAsState(initial = emptyList())
    val todos by repository.observeTodos().collectAsState(initial = emptyList())

    LaunchedEffect(currentUserId) {
        repository.checkAndSeedInitialData()
    }

    // Android back handler to navigate back to Home instead of exiting app
    BackHandler(enabled = currentScreen != ScreenDestination.HOME) {
        if (currentScreen == ScreenDestination.CATEGORY_DETAIL) {
            selectedCategoryId = null
        }
        currentScreen = ScreenDestination.HOME
    }

    val user = Firebase.auth.currentUser

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .width(310.dp)
                    .fillMaxHeight()
                    .testTag("side_navigation_drawer")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Drawer Header (.drawer-header in ghorkhata.html)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(EmeraldDeep, Color(0xFF04382B))
                                )
                            )
                            .padding(horizontal = 20.dp, vertical = 24.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Home,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "ঘরখাতা",
                                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "স্মার্ট পারিবারিক হিসাব",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = Color.White.copy(alpha = 0.78f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Google Account Box
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .background(EmeraldPrimary, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = (user?.displayName?.firstOrNull() ?: 'U').toString(),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = user?.displayName ?: "ব্যবহারকারী",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "ক্লাউড সিঙ্ক চালু ✓",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                            color = Color(0xFF6EE7B7)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Drawer Navigation Items (Matching #menu-drawer items in ghorkhata.html)
                    DrawerSectionHeader("মূল মেনু")

                    DrawerMenuItem(
                        label = "হোম",
                        icon = Icons.Default.Home,
                        selected = currentScreen == ScreenDestination.HOME,
                        onClick = {
                            currentScreen = ScreenDestination.HOME
                            selectedCategoryId = null
                            scope.launch { drawerState.close() }
                        }
                    )

                    DrawerMenuItem(
                        label = "রিপোর্ট ও চার্ট",
                        icon = Icons.Default.PieChart,
                        selected = currentScreen == ScreenDestination.REPORTS,
                        onClick = {
                            currentScreen = ScreenDestination.REPORTS
                            scope.launch { drawerState.close() }
                        }
                    )

                    DrawerMenuItem(
                        label = "Gemini AI এজেন্ট",
                        icon = Icons.Default.AutoAwesome,
                        selected = currentScreen == ScreenDestination.AI,
                        badge = "নতুন",
                        onClick = {
                            currentScreen = ScreenDestination.AI
                            scope.launch { drawerState.close() }
                        }
                    )

                    DrawerMenuItem(
                        label = "দোকান বাকি ও বিল খাতা",
                        icon = Icons.Default.Store,
                        selected = currentScreen == ScreenDestination.DUES,
                        badge = "${transactions.count { it.status == "baki" }}টি",
                        onClick = {
                            currentScreen = ScreenDestination.DUES
                            scope.launch { drawerState.close() }
                        }
                    )

                    DrawerMenuItem(
                        label = "টুডু ও বাজারের ফর্দ",
                        icon = Icons.Default.Checklist,
                        selected = currentScreen == ScreenDestination.TODOS,
                        onClick = {
                            currentScreen = ScreenDestination.TODOS
                            scope.launch { drawerState.close() }
                        }
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                    )

                    DrawerSectionHeader("ব্যবস্থাপনা ও সিঙ্ক")

                    DrawerMenuItem(
                        label = "খাতা ও ক্যাটাগরি ম্যানেজার",
                        icon = Icons.Default.Category,
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            showCategoryManager = true
                        }
                    )

                    DrawerMenuItem(
                        label = "ক্লাউড সিঙ্ক ও সেটিংস",
                        icon = Icons.Default.CloudSync,
                        selected = currentScreen == ScreenDestination.SETTINGS,
                        onClick = {
                            currentScreen = ScreenDestination.SETTINGS
                            scope.launch { drawerState.close() }
                        }
                    )

                    DrawerMenuItem(
                        label = "নমুনা ডেটা লোড করুন",
                        icon = Icons.Default.Refresh,
                        selected = false,
                        onClick = {
                            scope.launch {
                                repository.seedSampleDataNow()
                                drawerState.close()
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                AppTopBar(
                    currentMonth = currentMonth,
                    showMonthSelector = true,
                    userInitial = (user?.displayName?.firstOrNull() ?: 'G').toString(),
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onPrevMonth = { currentMonth = BnFormat.shiftMonthKey(currentMonth, -1) },
                    onNextMonth = { currentMonth = BnFormat.shiftMonthKey(currentMonth, 1) },
                    onResetCurrentMonth = { currentMonth = BnFormat.currentMonthKey() },
                    onAiClick = { currentScreen = ScreenDestination.AI },
                    onProfileClick = { currentScreen = ScreenDestination.SETTINGS }
                )
            },
            floatingActionButton = {
                // Single FAB on Home, Category Detail, or Dues (no duplicate buttons!)
                if (currentScreen == ScreenDestination.HOME ||
                    currentScreen == ScreenDestination.CATEGORY_DETAIL ||
                    currentScreen == ScreenDestination.DUES
                ) {
                    FloatingActionButton(
                        onClick = {
                            transactionToEdit = null
                            modalDefaultCategoryId = if (currentScreen == ScreenDestination.CATEGORY_DETAIL) selectedCategoryId else null
                            showTransactionModal = true
                        },
                        containerColor = EmeraldPrimary,
                        contentColor = Color.White,
                        elevation = FloatingActionButtonDefaults.elevation(6.dp),
                        modifier = Modifier.testTag("main_add_fab")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "নতুন হিসাব যোগ করুন")
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (currentScreen) {
                    ScreenDestination.HOME -> HomeDashboardView(
                        currentMonth = currentMonth,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        todos = todos,
                        onCategoryClick = { cat ->
                            selectedCategoryId = cat.id
                            currentScreen = ScreenDestination.CATEGORY_DETAIL
                        },
                        onTransactionClick = { tx ->
                            transactionToEdit = tx
                            showTransactionModal = true
                        },
                        onStatusToggle = { tx ->
                            scope.launch {
                                val next = if (tx.status == "paid") "baki" else "paid"
                                repository.updateTransactionStatus(tx.id, next)
                            }
                        },
                        onDeleteTransaction = { txId ->
                            scope.launch { repository.deleteTransaction(txId) }
                        },
                        onOpenReports = { currentScreen = ScreenDestination.REPORTS }
                    )

                    ScreenDestination.CATEGORY_DETAIL -> {
                        val activeCategory = categories.find { it.id == selectedCategoryId }
                            ?: categories.firstOrNull()
                        if (activeCategory != null) {
                            CategoryDetailView(
                                category = activeCategory,
                                currentMonth = currentMonth,
                                transactions = transactions,
                                todos = todos,
                                onBack = {
                                    selectedCategoryId = null
                                    currentScreen = ScreenDestination.HOME
                                },
                                onAddClick = { catId ->
                                    transactionToEdit = null
                                    modalDefaultCategoryId = catId
                                    showTransactionModal = true
                                },
                                onTransactionClick = { tx ->
                                    transactionToEdit = tx
                                    showTransactionModal = true
                                },
                                onStatusToggle = { tx ->
                                    scope.launch {
                                        val next = if (tx.status == "paid") "baki" else "paid"
                                        repository.updateTransactionStatus(tx.id, next)
                                    }
                                },
                                onDeleteTransaction = { txId ->
                                    scope.launch { repository.deleteTransaction(txId) }
                                },
                                onAddTodo = { title, qty, unit, est ->
                                    scope.launch {
                                        repository.saveTodo(
                                            TodoItem(
                                                title = title,
                                                quantity = qty,
                                                unit = unit,
                                                estimatedAmount = est,
                                                done = false
                                            )
                                        )
                                    }
                                },
                                onToggleTodoDone = { todo ->
                                    scope.launch { repository.saveTodo(todo.copy(done = !todo.done)) }
                                },
                                onDeleteTodo = { id ->
                                    scope.launch { repository.deleteTodo(id) }
                                },
                                onConvertToExpense = { todo ->
                                    transactionToEdit = TransactionItem(
                                        title = todo.title,
                                        amount = todo.estimatedAmount ?: 0.0,
                                        quantity = todo.quantity,
                                        unit = todo.unit,
                                        categoryId = todo.targetCategoryId
                                    )
                                    showTransactionModal = true
                                }
                            )
                        }
                    }

                    ScreenDestination.REPORTS -> ReportsView(
                        currentMonth = currentMonth,
                        transactions = transactions,
                        categories = categories,
                        onCategoryClick = { cat ->
                            selectedCategoryId = cat.id
                            currentScreen = ScreenDestination.CATEGORY_DETAIL
                        },
                        onTransactionClick = { tx ->
                            transactionToEdit = tx
                            showTransactionModal = true
                        }
                    )

                    ScreenDestination.DUES -> DuesLedgerView(
                        transactions = transactions,
                        categories = categories,
                        onTransactionClick = { tx ->
                            transactionToEdit = tx
                            showTransactionModal = true
                        },
                        onMarkPaid = { tx ->
                            scope.launch { repository.updateTransactionStatus(tx.id, "paid") }
                        },
                        onDelete = { txId ->
                            scope.launch { repository.deleteTransaction(txId) }
                        }
                    )

                    ScreenDestination.TODOS -> TodoMarketListView(
                        todos = todos,
                        onAddTodo = { title, qty, unit, est ->
                            scope.launch {
                                repository.saveTodo(
                                    TodoItem(
                                        title = title,
                                        quantity = qty,
                                        unit = unit,
                                        estimatedAmount = est,
                                        done = false
                                    )
                                )
                            }
                        },
                        onToggleDone = { todo ->
                            scope.launch { repository.saveTodo(todo.copy(done = !todo.done)) }
                        },
                        onDeleteTodo = { id ->
                            scope.launch { repository.deleteTodo(id) }
                        },
                        onConvertToExpense = { todo ->
                            transactionToEdit = TransactionItem(
                                title = todo.title,
                                amount = todo.estimatedAmount ?: 0.0,
                                quantity = todo.quantity,
                                unit = todo.unit,
                                categoryId = todo.targetCategoryId
                            )
                            showTransactionModal = true
                        }
                    )

                    ScreenDestination.AI -> GeminiAssistantView(
                        repository = repository,
                        currentMonth = currentMonth,
                        transactions = transactions,
                        categories = categories,
                        todos = todos
                    )

                    ScreenDestination.SETTINGS -> AppSettingsView(
                        repository = repository,
                        transactions = transactions,
                        categories = categories,
                        wallets = wallets,
                        todos = todos,
                        onSignOut = onSignOut
                    )
                }
            }
        }
    }

    if (showTransactionModal) {
        TransactionModal(
            transactionToEdit = transactionToEdit,
            defaultCategoryId = modalDefaultCategoryId,
            categories = categories,
            wallets = wallets,
            onDismiss = { showTransactionModal = false },
            onSave = { tx ->
                scope.launch {
                    repository.saveTransaction(tx)
                    showTransactionModal = false
                }
            },
            onSaveTodo = { todo ->
                scope.launch {
                    repository.saveTodo(todo)
                    showTransactionModal = false
                }
            },
            onDelete = { txId ->
                scope.launch {
                    repository.deleteTransaction(txId)
                    showTransactionModal = false
                }
            }
        )
    }

    if (showCategoryManager) {
        CategoryManagerModal(
            categories = categories,
            onDismiss = { showCategoryManager = false },
            onSaveCategory = { cat ->
                scope.launch { repository.saveCategory(cat) }
            },
            onDeleteCategory = { catId ->
                scope.launch { repository.deleteCategory(catId) }
            }
        )
    }
}

@Composable
private fun DrawerSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
    )
}

@Composable
private fun DrawerMenuItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
                if (badge != null) {
                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = if (selected) EmeraldPrimary else AmberAccent.copy(alpha = 0.18f)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = FontWeight.Bold,
                            color = if (selected) Color.White else AmberAccent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        },
        selected = selected,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = EmeraldPrimary.copy(alpha = 0.12f),
            selectedTextColor = EmeraldPrimary,
            unselectedTextColor = MaterialTheme.colorScheme.onSurface
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
    )
}
