package com.example.ai

import android.util.Log
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.repository.GhorkhataRepository
import com.example.util.BnFormat
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

data class ExecutedAgentAction(
    val type: String, // "ADD_TX", "ADD_TODO", "MARK_PAID", "DELETE_TX"
    val summaryBn: String
)

data class AgentResponse(
    val replyText: String,
    val executedActions: List<ExecutedAgentAction> = emptyList()
)

object GeminiAiService {
    private const val TAG = "GeminiAiService"

    private val actionItemSchema = Schema.obj(
        properties = mapOf(
            "actionType" to Schema.string(description = "One of: ADD_TX, ADD_TODO, MARK_PAID, DELETE_TX"),
            "title" to Schema.string(description = "Item or task title in Bengali"),
            "amount" to Schema.double(description = "Amount in Taka (0 if not applicable)"),
            "quantity" to Schema.double(description = "Quantity if specified", nullable = true),
            "unit" to Schema.string(description = "Bengali unit like কেজি, লিটার, টি, হালি, প্যাকেট", nullable = true),
            "categoryId" to Schema.string(description = "One of: income, bazar, dues, monthly, madrasa, medical, charity, fish_meat, transport", nullable = true),
            "status" to Schema.string(description = "paid, baki, or pending", nullable = true),
            "shopOrPerson" to Schema.string(description = "Shop or person name if due/baki", nullable = true),
            "note" to Schema.string(description = "Optional note", nullable = true)
        ),
        optionalProperties = listOf("quantity", "unit", "categoryId", "status", "shopOrPerson", "note")
    )

    private val agentResponseSchema = Schema.obj(
        properties = mapOf(
            "reply" to Schema.string(description = "Helpful, polite Bengali response explaining what was done or answering the financial question"),
            "actions" to Schema.array(
                items = actionItemSchema,
                description = "List of database actions to execute if the user asked to add, update, mark paid, or delete any transaction or todo"
            )
        )
    )

    private val agentConfig = generationConfig {
        responseMimeType = "application/json"
        responseSchema = agentResponseSchema
    }

    private val agentModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = agentConfig
        )
    }

    suspend fun processAgentChat(
        userMessage: String,
        currentMonth: String,
        transactions: List<TransactionItem>,
        categories: List<CategoryItem>,
        todos: List<TodoItem>,
        repository: GhorkhataRepository
    ): AgentResponse {
        val monthTxs = transactions.filter { BnFormat.monthKey(it.date) == currentMonth }
        val totalIncome = monthTxs.filter { it.categoryId == "income" }.sumOf { it.amount }
        val totalExpense = monthTxs.filter { it.categoryId != "income" && it.categoryId != "todo" }.sumOf { it.amount }
        val unpaidDues = transactions.filter { it.status == "baki" || it.status == "pending" }
        val totalDues = unpaidDues.sumOf { it.amount }

        // First try Cloud Gemini AI with structured Agent schema
        try {
            val contextPrompt = buildString {
                appendLine("তুমি 'ঘরখাতা' (Ghorkhata) অ্যাপের সর্বময় স্মার্ট AI এজেন্ট।")
                appendLine("তুমি চ্যাট ইন্টারফেস থেকে সরাসরি নতুন আয়/খরচ যোগ করতে পারো, বাকি পরিশোধ করতে পারো, বাজারের ফর্দ (Todo) যোগ করতে পারো, লেনদেন মুছতে পারো এবং খরচের হিসাব বিশ্লেষণ করতে পারো।")
                appendLine("আজকের তারিখ: ${BnFormat.currentDateIso()}, নির্বাচিত মাস: ${BnFormat.monthLabel(currentMonth)}")
                appendLine("চলতি মাসের মোট আয়: ৳$totalIncome, মোট খরচ: ৳$totalExpense, নিট ব্যালেন্স: ৳${totalIncome - totalExpense}, মোট অপরিশোধিত বাকি: ৳$totalDues")
                appendLine("সাম্প্রতিক লেনদেনসমূহ:")
                monthTxs.take(15).forEach { tx ->
                    appendLine("- [${tx.date}] ${tx.title}: ৳${tx.amount} (খাতা: ${tx.categoryId}, অবস্থা: ${tx.status})")
                }
                appendLine("অপরিশোধিত বাকি ও বিল:")
                unpaidDues.take(10).forEach { d ->
                    appendLine("- ${d.title} (${d.shopOrPerson ?: ""}): ৳${d.amount}")
                }
                appendLine("ব্যবহারকারীর বার্তা: \"$userMessage\"")
                appendLine("ব্যবহারকারী যদি কোনো খরচ, আয়, বাকি বা টাস্ক যোগ/পরিবর্তন/ডিলিট করতে বলেন, তবে actions অ্যারেতে তা যুক্ত করো এবং reply-তে সুন্দর বাংলায় নিশ্চিত করো। আর যদি বিশ্লেষণ বা পরামর্শ চান, তবে actions খালি রেখে reply-তে বিস্তারিত বাংলায় উত্তর দাও।")
            }

            val rawJson = withTimeout(22_000L) {
                val res = agentModel.generateContent(contextPrompt)
                res.text ?: throw IllegalStateException("Empty AI response")
            }

            val json = JSONObject(rawJson)
            val reply = json.optString("reply", "")
            val actionsArr = json.optJSONArray("actions") ?: JSONArray()
            val executed = mutableListOf<ExecutedAgentAction>()

            for (i in 0 until actionsArr.length()) {
                val act = actionsArr.getJSONObject(i)
                val type = act.optString("actionType", "")
                val title = act.optString("title", "").trim()
                val amount = act.optDouble("amount", 0.0)
                val qty = if (act.has("quantity") && !act.isNull("quantity")) act.optDouble("quantity") else null
                val unit = act.optString("unit", "").takeIf { it.isNotBlank() && it != "null" }
                val catId = act.optString("categoryId", "bazar").ifBlank { "bazar" }
                val status = act.optString("status", if (catId == "dues") "baki" else "paid")
                val shop = act.optString("shopOrPerson", "").takeIf { it.isNotBlank() && it != "null" }
                val note = act.optString("note", "").takeIf { it.isNotBlank() && it != "null" }

                when (type) {
                    "ADD_TX" -> {
                        if (title.isNotBlank() && amount > 0) {
                            val unitPrice = if (qty != null && qty > 0) amount / qty else null
                            repository.saveTransaction(
                                TransactionItem(
                                    categoryId = catId,
                                    walletId = "cash",
                                    title = title,
                                    amount = amount,
                                    quantity = qty,
                                    unit = unit,
                                    unitPrice = unitPrice,
                                    date = BnFormat.currentDateIso(),
                                    status = status,
                                    shopOrPerson = shop,
                                    note = note
                                )
                            )
                            val catName = categories.find { it.id == catId }?.name ?: catId
                            val qtyBadge = if (qty != null && qty > 0) " (${BnFormat.formatQuantity(qty, unit)})" else ""
                            executed.add(
                                ExecutedAgentAction(
                                    "ADD_TX",
                                    "যোগ হয়েছে: $title$qtyBadge — ${BnFormat.formatTaka(amount)} [$catName]"
                                )
                            )
                        }
                    }
                    "ADD_TODO" -> {
                        if (title.isNotBlank()) {
                            repository.saveTodo(
                                TodoItem(
                                    title = title,
                                    quantity = qty,
                                    unit = unit,
                                    estimatedAmount = amount.takeIf { it > 0 },
                                    done = false
                                )
                            )
                            executed.add(
                                ExecutedAgentAction("ADD_TODO", "ফর্দে যোগ হয়েছে: $title")
                            )
                        }
                    }
                    "MARK_PAID" -> {
                        val target = unpaidDues.firstOrNull {
                            it.title.contains(title, ignoreCase = true) ||
                                    (it.shopOrPerson?.contains(title, ignoreCase = true) == true)
                        } ?: unpaidDues.firstOrNull()
                        if (target != null) {
                            repository.updateTransactionStatus(target.id, "paid")
                            executed.add(
                                ExecutedAgentAction(
                                    "MARK_PAID",
                                    "পরিশোধিত মার্ক করা হয়েছে: ${target.title} (${BnFormat.formatTaka(target.amount)})"
                                )
                            )
                        }
                    }
                    "DELETE_TX" -> {
                        val target = transactions.firstOrNull {
                            it.title.contains(title, ignoreCase = true)
                        }
                        if (target != null) {
                            repository.deleteTransaction(target.id)
                            executed.add(
                                ExecutedAgentAction(
                                    "DELETE_TX",
                                    "মুছে ফেলা হয়েছে: ${target.title} (${BnFormat.formatTaka(target.amount)})"
                                )
                            )
                        }
                    }
                }
            }

            if (reply.isNotBlank()) {
                return AgentResponse(replyText = reply, executedActions = executed)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Cloud Gemini call fell back to Local Smart Agent: ${e.message}")
        }

        // Fallback: Deterministic Smart Bengali Agent Engine (0ms, works 100% offline or when Cloud AI is unreachable)
        return runLocalSmartAgent(
            userMessage = userMessage,
            currentMonth = currentMonth,
            transactions = transactions,
            categories = categories,
            todos = todos,
            repository = repository
        )
    }

    private suspend fun runLocalSmartAgent(
        userMessage: String,
        currentMonth: String,
        transactions: List<TransactionItem>,
        categories: List<CategoryItem>,
        todos: List<TodoItem>,
        repository: GhorkhataRepository
    ): AgentResponse {
        val msg = userMessage.trim()
        val lower = msg.lowercase()
        val monthTxs = transactions.filter { BnFormat.monthKey(it.date) == currentMonth }
        val income = monthTxs.filter { it.categoryId == "income" }.sumOf { it.amount }
        val expense = monthTxs.filter { it.categoryId != "income" && it.categoryId != "todo" }.sumOf { it.amount }
        val balance = income - expense
        val unpaidDues = transactions.filter { it.status == "baki" || it.status == "pending" }
        val totalDues = unpaidDues.sumOf { it.amount }
        val executed = mutableListOf<ExecutedAgentAction>()

        // 1. Check if user wants to mark a due/bill as paid
        if (Regex("পরিশোধ|শোধ|দিয়েছি|দিয়েছি|paid|clear").containsMatchIn(lower) &&
            Regex("বাকি|বিল|স্টোর|দোকান|ভাড়া").containsMatchIn(lower) &&
            !Regex("\\d|[০-৯]").containsMatchIn(lower)
        ) {
            val matched = unpaidDues.filter {
                msg.contains(it.title, ignoreCase = true) ||
                        (it.shopOrPerson != null && msg.contains(it.shopOrPerson, ignoreCase = true))
            }.ifEmpty { unpaidDues.take(1) }

            if (matched.isNotEmpty()) {
                for (item in matched) {
                    repository.updateTransactionStatus(item.id, "paid")
                    executed.add(
                        ExecutedAgentAction(
                            "MARK_PAID",
                            "পরিশোধিত: ${item.title} — ${BnFormat.formatTaka(item.amount)}"
                        )
                    )
                }
                return AgentResponse(
                    replyText = "আলহামদুলিল্লাহ! আমি আপনার খাতায় ${matched.joinToString(", ") { "'${it.title}' (${BnFormat.formatTaka(it.amount)})" }} পরিশোধিত হিসেবে আপডেট করে দিয়েছি।",
                    executedActions = executed
                )
            }
        }

        // 2. Check if user wants to delete an entry
        if (Regex("মুছে|ডিলিট|বাদ দাও|delete|remove").containsMatchIn(lower)) {
            val target = transactions.firstOrNull { tx ->
                tx.title.split(" ").any { word -> word.length >= 2 && msg.contains(word, ignoreCase = true) }
            }
            if (target != null) {
                repository.deleteTransaction(target.id)
                executed.add(
                    ExecutedAgentAction(
                        "DELETE_TX",
                        "মুছে ফেলা হয়েছে: ${target.title} (${BnFormat.formatTaka(target.amount)})"
                    )
                )
                return AgentResponse(
                    replyText = "'${target.title}' (${BnFormat.formatTaka(target.amount)}) লেনদেনটি আপনার খাতা থেকে মুছে ফেলা হয়েছে।",
                    executedActions = executed
                )
            }
        }

        // 3. Check if user wants to add a Todo / Market List item without immediate expense
        if (Regex("ফর্দ|ফর্দে|টাস্ক|টাস্কে|টুডু|কিনতে হবে|আনতে হবে|দিতে হবে").containsMatchIn(lower) &&
            !Regex("কিনেছি|কিনলাম|খরচ হলো|দিলাম").containsMatchIn(lower)
        ) {
            val cleanTitle = msg
                .replace(Regex("ফর্দে|ফর্দ|টাস্কে|টাস্ক|টুডুতে|টুডু|যোগ করো|লিখো|রাখো"), "")
                .trim()
                .ifBlank { msg }
            val parsed = parseOfflineBengali(BnFormat.toEnDigits(cleanTitle), cleanTitle)
            repository.saveTodo(
                TodoItem(
                    title = parsed.title.ifBlank { cleanTitle },
                    quantity = parsed.quantity,
                    unit = parsed.unit,
                    estimatedAmount = parsed.amount.takeIf { it > 0 },
                    targetCategoryId = parsed.categoryId,
                    done = false
                )
            )
            executed.add(
                ExecutedAgentAction(
                    "ADD_TODO",
                    "বাজারের ফর্দে যোগ হয়েছে: ${parsed.title.ifBlank { cleanTitle }}"
                )
            )
            return AgentResponse(
                replyText = "আপনার টুডু / বাজারের ফর্দে '${parsed.title.ifBlank { cleanTitle }}' সফলভাবে যুক্ত করা হয়েছে!",
                executedActions = executed
            )
        }

        // 4. Check if the message contains amounts to record one or multiple transactions!
        // Make sure it's not a preset question like "৫০/৩০/২০ নিয়মে বাজেট"
        val isAnalysisQuestion = Regex("বিশ্লেষণ|সাশ্রয়|সাশ্রয়|পরামর্শ|বাজেট প্ল্যান|রিভিউ|কত খরচ|কত টাকা আছে|ব্যালেন্স কত|হিসাব দেখাও|৫০/৩০/২০").containsMatchIn(lower)
        val hasDigits = Regex("\\d|[০-৯]").containsMatchIn(msg)

        if (!isAnalysisQuestion && hasDigits) {
            // Split into multiple clauses if user wrote e.g. "২ কেজি আলু ১২০ টাকা আর ১ লিটার তেল ১৮০ টাকা"
            val clauses = msg.split(Regex("""[,;\n]|(?:\s+আর\s+)|(?:\s+এবং\s+)"""))
                .map { it.trim() }
                .filter { it.isNotBlank() && Regex("\\d|[০-৯]").containsMatchIn(it) }

            val addedItems = mutableListOf<String>()
            for (clause in clauses) {
                val parsed = parseOfflineBengali(BnFormat.toEnDigits(clause), clause)
                if (parsed.amount > 0) {
                    val unitPrice = if (parsed.quantity != null && parsed.quantity > 0) parsed.amount / parsed.quantity else null
                    repository.saveTransaction(
                        TransactionItem(
                            categoryId = parsed.categoryId,
                            walletId = parsed.walletId,
                            title = parsed.title,
                            amount = parsed.amount,
                            quantity = parsed.quantity,
                            unit = parsed.unit,
                            unitPrice = unitPrice,
                            date = BnFormat.currentDateIso(),
                            status = parsed.status,
                            shopOrPerson = parsed.shopOrPerson,
                            note = "AI এজেন্টের মাধ্যমে সংযোজিত"
                        )
                    )
                    val catName = categories.find { it.id == parsed.categoryId }?.name ?: "বাজার সদাই"
                    val qtyPart = if (parsed.quantity != null && parsed.quantity > 0) " (${BnFormat.formatQuantity(parsed.quantity, parsed.unit)})" else ""
                    val summary = "${parsed.title}$qtyPart — ${BnFormat.formatTaka(parsed.amount)} [$catName]"
                    executed.add(ExecutedAgentAction("ADD_TX", "যোগ হয়েছে: $summary"))
                    addedItems.add(summary)
                }
            }

            if (addedItems.isNotEmpty()) {
                return AgentResponse(
                    replyText = "আমি আপনার ঘরখাতায় নিচের হিসাবটি সফলভাবে যুক্ত করে দিয়েছি:\n" +
                            addedItems.joinToString("\n") { "• $it" } +
                            "\n\nআর কোনো হিসাব যোগ বা পরিবর্তন করতে চাইলে আমাকে বলতে পারেন!",
                    executedActions = executed
                )
            }
        }

        // 5. Financial Analysis, Savings, Budget, Audit, or General Query
        val breakdown = categories
            .filter { it.type == "expense" || it.type == "dues" }
            .map { cat ->
                cat to monthTxs.filter { it.categoryId == cat.id }.sumOf { it.amount }
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }

        return when {
            Regex("বাকি|বিল|রিভিউ|audit|due").containsMatchIn(lower) -> {
                val duesText = if (unpaidDues.isEmpty()) {
                    "আলহামদুলিল্লাহ! বর্তমানে আপনার কোনো অপরিশোধিত দোকান বাকি বা বকেয়া বিল নেই।"
                } else {
                    buildString {
                        appendLine("📋 **অপরিশোধিত বাকি ও মাসিক বিলের রিভিউ:**")
                        appendLine("মোট বকেয়া: **${BnFormat.formatTaka(totalDues)}** (${BnFormat.toBnDigits(unpaidDues.size)}টি এন্ট্রি)")
                        appendLine()
                        unpaidDues.forEachIndexed { idx, d ->
                            val shop = if (!d.shopOrPerson.isNullOrBlank()) " (${d.shopOrPerson})" else ""
                            val st = if (d.status == "baki") "বাকি" else "অপেক্ষমান"
                            appendLine("${BnFormat.toBnDigits(idx + 1)}. ${d.title}$shop — **${BnFormat.formatTaka(d.amount)}** [$st]")
                        }
                        appendLine()
                        append("💡 **পরামর্শ:** মাসের শুরুতেই জরুরি ইউটিলিটি বিল ও দোকানের বাকি পরিশোধ করলে জরিমানা ও বাড়তি চাপ এড়ানো সহজ হয়। আপনি চাইলে আমাকে বললেই আমি যেকোনো বাকি 'পরিশোধিত' মার্ক করে দেব!")
                    }
                }
                AgentResponse(replyText = duesText)
            }

            Regex("বাজেট|৫০/৩০/২০|পরিকল্পনা|budget").containsMatchIn(lower) -> {
                val baseIncome = if (income > 0) income else 35000.0
                val needs = baseIncome * 0.50
                val wants = baseIncome * 0.30
                val savings = baseIncome * 0.20
                val reply = buildString {
                    appendLine("📊 **৫০/৩০/২০ নিয়মে আপনার মাসিক বাজেট পরিকল্পনা (${BnFormat.monthLabel(currentMonth)}):**")
                    appendLine("আপনার মাসিক আয় **${BnFormat.formatTaka(baseIncome)}** ধরে আদর্শ বাজেট বরাদ্দ:")
                    appendLine()
                    appendLine("• **৫০% জরুরি প্রয়োজন (${BnFormat.formatTaka(needs)}):** বাসা ভাড়া, বাজার সদাই, মাসিক বিদ্যুৎ/গ্যাস/পানি বিল, মাদ্রাসা ফি ও ওষুধ।")
                    appendLine("• **৩০% জীবনযাত্রা ও অন্যান্য (${BnFormat.formatTaka(wants)}):** মাছ-মাংস, অতিথি আপ্যায়ন, যাতায়াত ও দান-সদকা।")
                    appendLine("• **২০% ভবিষ্যৎ সঞ্চয় (${BnFormat.formatTaka(savings)}):** জরুরি তহবিল ও ব্যাংক/বিকাশ সঞ্চয়।")
                    appendLine()
                    append("বর্তমানে আপনার খরচ হয়েছে **${BnFormat.formatTaka(expense)}**, এবং হাতে উদ্বৃত্ত আছে **${BnFormat.formatTaka(balance)}**।")
                }
                AgentResponse(replyText = reply)
            }

            Regex("সাশ্রয়|সাশ্রয়|কমানো|সঞ্চয়|সঞ্চয়|saving").containsMatchIn(lower) -> {
                val topCat = breakdown.firstOrNull()
                val reply = buildString {
                    appendLine("💡 **খরচ কমিয়ে সাশ্রয় বাড়ানোর ৪টি কার্যকরী পরামর্শ:**")
                    appendLine()
                    if (topCat != null) {
                        appendLine("১. **${topCat.first.name} খাতে নজর দিন:** এই মাসে সবচেয়ে বেশি খরচ হয়েছে '${topCat.first.name}' খাতে (**${BnFormat.formatTaka(topCat.second)}**)। পাইকারি দরে মাসের শুরুতে একসাথে শুকনো বাজার (চাল, ডাল, তেল) কিনলে ১০-১৫% সাশ্রয় সম্ভব।")
                    } else {
                        appendLine("১. **পাইকারি কেনাকাটা:** চাল, ডাল ও তেল খুচরা না কিনে মাসের শুরুতে একসাথে কিনলে খরচ ১০-১৫% কমে।")
                    }
                    appendLine("২. **বাজারের ফর্দ (To-Do) অনুসরণ:** বাজারে যাওয়ার আগে ঘরখাতার 'টুডু লিস্ট'-এ ফর্দ লিখে নিন, এতে অপ্রয়োজনীয় কেনাকাটা বন্ধ হবে।")
                    appendLine("৩. **দোকান বাকি কমানো:** বাকিতে কেনাকাটা করলে প্রায়ই বেশি কেনা হয়ে যায়। বর্তমানে আপনার বাকি আছে **${BnFormat.formatTaka(totalDues)}**।")
                    append("৪. **আয়ের অন্তত ১৫-২০% প্রারম্ভিক সঞ্চয়:** বেতন বা আয় পাওয়ার সাথে সাথেই একটি নির্দিষ্ট অংশ আলাদা ওয়ালেটে সরিয়ে রাখুন।")
                }
                AgentResponse(replyText = reply)
            }

            else -> {
                // Comprehensive Monthly Analysis
                val pct = if (income > 0) ((expense / income) * 100).roundToInt() else 0
                val reply = buildString {
                    appendLine("📈 **${BnFormat.monthLabel(currentMonth)} মাসের পূর্ণাঙ্গ হিসাব বিশ্লেষণ:**")
                    appendLine("• মোট আয়: **${BnFormat.formatTaka(income)}**")
                    appendLine("• মোট খরচ: **${BnFormat.formatTaka(expense)}** (আয়ের ${BnFormat.toBnDigits(pct)}%)")
                    appendLine("• বর্তমান ব্যালেন্স: **${BnFormat.formatTaka(balance)}**")
                    appendLine("• অপরিশোধিত বাকি: **${BnFormat.formatTaka(totalDues)}**")
                    if (breakdown.isNotEmpty()) {
                        appendLine()
                        appendLine("**প্রধান খরচের খাতসমূহ:**")
                        breakdown.take(4).forEach { (cat, amt) ->
                            val share = if (expense > 0) ((amt / expense) * 100).roundToInt() else 0
                            appendLine("• ${cat.name}: **${BnFormat.formatTaka(amt)}** (${BnFormat.toBnDigits(share)}%)")
                        }
                    }
                    appendLine()
                    append("🤖 **টিপস:** আপনি সরাসরি চ্যাটে লিখেও যেকোনো হিসাব যোগ করতে পারেন—যেমন: *\"২ কেজি আলু ১২০ টাকা\"* বা *\"ফর্দে সয়াবিন তেল যোগ করো\"*!")
                }
                AgentResponse(replyText = reply)
            }
        }
    }

    data class ParsedExpense(
        val title: String,
        val amount: Double,
        val quantity: Double?,
        val unit: String?,
        val categoryId: String,
        val walletId: String,
        val date: String,
        val status: String,
        val shopOrPerson: String? = null
    )

    fun parseOfflineBengali(normalizedEn: String, rawOriginal: String): ParsedExpense {
        val qtyUnitRegex = Regex("""(\d+(?:\.\d+)?)\s*(কেজি|গ্রাম|লিটার|মিলি|টি|হালি|ডজন|প্যাকেট|বস্তা|বক্স|বোতল|বার)""")
        val qtyMatch = qtyUnitRegex.find(normalizedEn)
        val quantity = qtyMatch?.groupValues?.get(1)?.toDoubleOrNull()
        val unit = qtyMatch?.groupValues?.get(2)

        // Remove the matched quantity+unit substring so we don't confuse quantity with Taka amount
        val textWithoutQty = if (qtyMatch != null) {
            normalizedEn.removeRange(qtyMatch.range)
        } else {
            normalizedEn
        }

        val amountRegex = Regex("""(\d+(?:\.\d+)?)\s*(?:টাকা|ট|tk|taka|/-)?""", RegexOption.IGNORE_CASE)
        val amountMatch = amountRegex.findAll(textWithoutQty).lastOrNull()
        val amount = amountMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

        val lower = rawOriginal.lowercase()
        val isBaki = Regex("বাকি|ধার|দেনা|কর্জ|বকেয়া|due").containsMatchIn(lower)
        val categoryId = when {
            Regex("বেতন|মাইনে|লাভ|আয়|আয়|পাওয়া|পাওয়া|income|salary").containsMatchIn(lower) -> "income"
            isBaki && Regex("স্টোর|দোকান|মুদি|ফার্মেসি").containsMatchIn(lower) -> "dues"
            Regex("মাছ|মাংস|ইলিশ|রুই|গরু|খাসি|মুরগি|পোল্ট্রি|beef|fish|chicken").containsMatchIn(lower) -> "fish_meat"
            Regex("চাল|ডাল|আলু|পেঁয়াজ|তেল|লবণ|সবজি|রসুন|আদা|টমেটো|মরিচ|ডিম|দুধ|চিনি|আটা|ময়দা|ময়দা|বাজার").containsMatchIn(lower) -> "bazar"
            Regex("বিদ্যুৎ|কারেন্ট|গ্যাস|পানি|ওয়াইফাই|ওয়াইফাই|ভাড়া|ভাড়া|বাড়িভাড়া|বিল|bill|rent").containsMatchIn(lower) -> "monthly"
            Regex("মাদ্রাসা|স্কুল|কলেজ|বই|খাতা|টিউশন|পরীক্ষা|সেশন|বেতন").containsMatchIn(lower) -> "madrasa"
            Regex("ওষুধ|ডাক্তার|প্রেসক্রিপশন|হাসপাতাল|প্যারাসিটামল|স্যালাইন|মেডিকেল|ফার্মেসি").containsMatchIn(lower) -> "medical"
            Regex("দান|সদকা|যাকাত|মসজিদ|ফিতরা|এতিমখানা").containsMatchIn(lower) -> "charity"
            Regex("বাস|রিকশা|সিএনজি|মেট্রো|যাতায়াত|যাতায়াত|গাড়ি|গাড়ি").containsMatchIn(lower) -> "transport"
            isBaki -> "dues"
            else -> "bazar"
        }

        val walletId = when {
            Regex("বিকাশ|বিকাশে|bkash").containsMatchIn(lower) -> "bkash"
            Regex("নগদে|nagad").containsMatchIn(lower) -> "nagad"
            Regex("ব্যাংক|ব্যাংকে|bank").containsMatchIn(lower) -> "bank"
            else -> "cash"
        }

        val status = if (isBaki) "baki" else "paid"

        var title = rawOriginal
            .replace(Regex("""[০-৯\d]+(?:\.[০-৯\d]+)?\s*(?:কেজি|গ্রাম|লিটার|মিলি|টি|হালি|ডজন|প্যাকেট|বস্তা|বক্স|বোতল|বার)"""), "")
            .replace(Regex("""[০-৯\d]+(?:\.[০-৯\d]+)?\s*(?:টাকা|ট|tk|taka|/-)?""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""(?:আজকে|আজ|গতকাল|কিনেছি|কিনলাম|নিলাম|দিলাম|খরচ|হলো|যোগ করো|করো|রাখলাম|বাকি|নগদ)"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .trim(',', '-', '।')

        if (title.isBlank()) title = rawOriginal.trim()

        val shopMatch = Regex("""(\S+\s*(?:স্টোর|দোকান|ফার্মেসি|মার্ট))""").find(rawOriginal)
        val shopOrPerson = shopMatch?.groupValues?.get(1)

        return ParsedExpense(
            title = title,
            amount = amount,
            quantity = quantity,
            unit = unit,
            categoryId = categoryId,
            walletId = walletId,
            date = BnFormat.currentDateIso(),
            status = status,
            shopOrPerson = shopOrPerson
        )
    }
}
