package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.model.WalletItem
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoseExpense
import com.example.util.BnFormat

@Composable
fun TransactionModal(
    transactionToEdit: TransactionItem? = null,
    defaultCategoryId: String? = null,
    categories: List<CategoryItem>,
    wallets: List<WalletItem>,
    onDismiss: () -> Unit,
    onSave: (TransactionItem) -> Unit,
    onSaveTodo: ((TodoItem) -> Unit)? = null,
    onDelete: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    val initialCatId = transactionToEdit?.categoryId
        ?: defaultCategoryId
        ?: categories.firstOrNull { it.id == "bazar" }?.id
        ?: "bazar"

    var isTodoMode by remember {
        mutableStateOf(transactionToEdit == null && initialCatId == "todo")
    }
    var selectedCategoryId by remember {
        mutableStateOf(if (initialCatId == "todo") "bazar" else initialCatId)
    }

    var title by remember { mutableStateOf(transactionToEdit?.title ?: "") }
    var amountStr by remember {
        mutableStateOf(
            if (transactionToEdit != null && transactionToEdit.amount > 0)
                BnFormat.toBnDigits(
                    if (transactionToEdit.amount % 1.0 == 0.0)
                        transactionToEdit.amount.toLong().toString()
                    else transactionToEdit.amount.toString()
                )
            else ""
        )
    }
    var quantityStr by remember {
        mutableStateOf(
            if (transactionToEdit?.quantity != null && transactionToEdit.quantity > 0)
                BnFormat.toBnDigits(
                    if (transactionToEdit.quantity % 1.0 == 0.0)
                        transactionToEdit.quantity.toLong().toString()
                    else transactionToEdit.quantity.toString()
                )
            else ""
        )
    }
    var selectedUnit by remember { mutableStateOf(transactionToEdit?.unit ?: "কেজি") }
    var selectedWalletId by remember { mutableStateOf(transactionToEdit?.walletId ?: "cash") }
    var selectedDate by remember {
        mutableStateOf(transactionToEdit?.date ?: BnFormat.currentDateIso())
    }
    var status by remember {
        mutableStateOf(
            transactionToEdit?.status
                ?: if (initialCatId == "dokan_baki") "baki" else "paid"
        )
    }
    var shopOrPerson by remember { mutableStateOf(transactionToEdit?.shopOrPerson ?: "") }
    var note by remember { mutableStateOf(transactionToEdit?.note ?: "") }
    var todoPriority by remember { mutableStateOf("medium") }

    val units = listOf("কেজি", "গ্রাম", "লিটার", "মিলি", "টি", "হালি", "ডজন", "প্যাকেট", "বস্তা", "বক্স", "বোতল", "পিস")

    val amountNum = BnFormat.toEnDigits(amountStr).toDoubleOrNull() ?: 0.0
    val qtyNum = BnFormat.toEnDigits(quantityStr).toDoubleOrNull()
    val unitPrice = if (qtyNum != null && qtyNum > 0 && amountNum > 0) amountNum / qtyNum else null

    val currentCategory = categories.find { it.id == selectedCategoryId }
    val isIncomeCategory = currentCategory?.type == "income"

    fun openDatePicker() {
        val parts = selectedDate.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val month = (parts.getOrNull(1)?.toIntOrNull() ?: 11) - 1
        val day = parts.getOrNull(2)?.toIntOrNull() ?: 11

        DatePickerDialog(
            context,
            { _, y, m, d ->
                selectedDate = "%04d-%02d-%02d".format(y, m + 1, d)
            },
            year,
            month,
            day
        ).show()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 680.dp)
                .testTag("transaction_modal")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Modal Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when {
                            transactionToEdit != null -> "হিসাব সম্পাদনা করুন"
                            isTodoMode -> "নতুন টাস্ক / বাজারের ফর্দ"
                            else -> "নতুন হিসাব যোগ করুন"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (transactionToEdit != null && onDelete != null) {
                            IconButton(
                                onClick = { onDelete(transactionToEdit.id) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "মুছে ফেলুন",
                                    tint = RoseExpense
                                )
                            }
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(34.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "বন্ধ করুন",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode Switcher (লেনদেন vs টাস্ক) when adding new entry
                if (transactionToEdit == null && onSaveTodo != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val txSelected = !isTodoMode
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (txSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                            shadowElevation = if (txSelected) 2.dp else 0.dp,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { isTodoMode = false }
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "লেনদেন (আয়/খরচ)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (txSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        val todoSelected = isTodoMode
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (todoSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                            shadowElevation = if (todoSelected) 2.dp else 0.dp,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { isTodoMode = true }
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "টাস্ক / ফর্দ",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (todoSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Category Selector Chips ("খাতা বেছে নিন") in Transaction mode
                if (!isTodoMode) {
                    Text(
                        text = "খাতা বেছে নিন",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.filter { it.id != "todo" }.forEach { cat ->
                            val isSelected = selectedCategoryId == cat.id
                            val catColor = IconRegistry.parseColor(cat.color)
                            val catBg = IconRegistry.parseColor(cat.bgLight)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) catBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                modifier = Modifier
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) catColor else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        selectedCategoryId = cat.id
                                        if (cat.id == "dokan_baki") {
                                            status = "baki"
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = IconRegistry.getIcon(cat.icon),
                                        contentDescription = cat.name,
                                        tint = if (isSelected) catColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = cat.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) catColor else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(if (isTodoMode) "কাজের বিবরণ বা পণ্যের নাম" else "বিবরণ") },
                    placeholder = {
                        Text(
                            when {
                                isTodoMode -> "যেমন: বাজার থেকে পোলাওয়ের চাল আনতে হবে..."
                                isIncomeCategory -> "যেমন: বেতন, বোনাস, ব্যবসা..."
                                else -> "যেমন: আলু ও পেঁয়াজ, রিকশা ভাড়া..."
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_title_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Amount Input + Live Bengali Taka Preview
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = {
                        Text(if (isTodoMode) "আনুমানিক দাম (৳ - ঐচ্ছিক)" else "টাকার পরিমাণ (৳)")
                    },
                    placeholder = { Text("০") },
                    trailingIcon = {
                        if (amountNum > 0) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldPrimary.copy(alpha = 0.12f),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text(
                                    text = BnFormat.formatTaka(amountNum),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_amount_input"),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity & Unit Row (Available for non-income transactions & todos)
                if (!isIncomeCategory) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "বস্তুর পরিমাণ ও একক (ঐচ্ছিক)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (unitPrice != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldPrimary.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = "দর: ${BnFormat.formatTaka(unitPrice)} / $selectedUnit",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = quantityStr,
                        onValueChange = { quantityStr = it },
                        label = { Text("বস্তুর পরিমাণ (যেমন: ২ বা ১.৫)") },
                        placeholder = { Text("যেমন: ২") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tx_qty_input"),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        units.forEach { unit ->
                            FilterChip(
                                selected = selectedUnit == unit,
                                onClick = { selectedUnit = unit },
                                label = { Text(unit, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (!isTodoMode) {
                    // Date Field (তারিখ) with DatePickerDialog + আজ / গতকাল quick chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "তারিখ",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val todayIso = BnFormat.currentDateIso()
                            val yesterdayIso = BnFormat.yesterdayDateIso()

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedDate == todayIso) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { selectedDate = todayIso }
                            ) {
                                Text(
                                    text = "আজ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedDate == todayIso) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedDate == yesterdayIso) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { selectedDate = yesterdayIso }
                            ) {
                                Text(
                                    text = "গতকাল",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedDate == yesterdayIso) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { openDatePicker() }
                            .testTag("tx_date_picker")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 13.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = BnFormat.formatBnDateFull(selectedDate),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "তারিখ পরিবর্তন করতে ট্যাপ করুন (${BnFormat.toBnDigits(selectedDate)})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "তারিখ নির্বাচন",
                                tint = EmeraldPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Status Selector ("অবস্থা": পরিশোধিত ✓ | অপেক্ষমান | বাকি আছে)
                    Text(
                        text = "অবস্থা",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusOptionButton(
                            label = if (isIncomeCategory) "প্রাপ্ত ✓" else "পরিশোধিত ✓",
                            selected = status == "paid",
                            activeColor = EmeraldPrimary,
                            activeBg = Color(0xFFDDF3E9),
                            onClick = { status = "paid" },
                            modifier = Modifier.weight(1f)
                        )
                        StatusOptionButton(
                            label = "অপেক্ষমান",
                            selected = status == "pending",
                            activeColor = AmberAccent,
                            activeBg = Color(0xFFFEF0DC),
                            onClick = { status = "pending" },
                            modifier = Modifier.weight(1f)
                        )
                        StatusOptionButton(
                            label = "বাকি আছে",
                            selected = status == "baki",
                            activeColor = RoseExpense,
                            activeBg = Color(0xFFFDE8EC),
                            onClick = { status = "baki" },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Shop or Person Name if baki / pending
                    if (status == "baki" || status == "pending" || selectedCategoryId == "dokan_baki") {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = shopOrPerson,
                            onValueChange = { shopOrPerson = it },
                            label = { Text("দোকান বা ব্যক্তির নাম (ঐচ্ছিক)") },
                            placeholder = { Text("যেমন: বিসমিল্লাহ স্টোর / রহিম ভাই") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Wallet Selection
                    Text(
                        text = "হিসাব / ওয়ালেট",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        wallets.forEach { w ->
                            FilterChip(
                                selected = selectedWalletId == w.id,
                                onClick = { selectedWalletId = w.id },
                                label = { Text(w.name, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary.copy(alpha = 0.15f),
                                    selectedLabelColor = EmeraldPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Note / Comment Field ("নোট / মন্তব্য (ঐচ্ছিক)" — Restored!)
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("নোট / মন্তব্য (ঐচ্ছিক)") },
                        placeholder = { Text("অতিরিক্ত তথ্য বা মনে রাখার নোট লিখুন...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tx_note_input"),
                        shape = RoundedCornerShape(14.dp),
                        minLines = 2,
                        maxLines = 3
                    )
                } else {
                    // Priority Selector in Todo Mode
                    Text(
                        text = "অগ্রাধিকার",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusOptionButton(
                            label = "জরুরি",
                            selected = todoPriority == "high",
                            activeColor = RoseExpense,
                            activeBg = Color(0xFFFDE8EC),
                            onClick = { todoPriority = "high" },
                            modifier = Modifier.weight(1f)
                        )
                        StatusOptionButton(
                            label = "মাঝারি",
                            selected = todoPriority == "medium",
                            activeColor = AmberAccent,
                            activeBg = Color(0xFFFEF0DC),
                            onClick = { todoPriority = "medium" },
                            modifier = Modifier.weight(1f)
                        )
                        StatusOptionButton(
                            label = "সাধারণ",
                            selected = todoPriority == "low",
                            activeColor = EmeraldPrimary,
                            activeBg = Color(0xFFDDF3E9),
                            onClick = { todoPriority = "low" },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Submit & Cancel Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(0.42f)
                            .height(48.dp)
                    ) {
                        Text("বাতিল", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            if (isTodoMode && onSaveTodo != null) {
                                if (title.isNotBlank()) {
                                    onSaveTodo(
                                        TodoItem(
                                            title = title.trim(),
                                            quantity = qtyNum,
                                            unit = if (qtyNum != null) selectedUnit else null,
                                            estimatedAmount = if (amountNum > 0) amountNum else null,
                                            done = false,
                                            targetCategoryId = "bazar"
                                        )
                                    )
                                }
                            } else {
                                if (title.isNotBlank() && amountNum > 0) {
                                    val finalNote = buildString {
                                        if (note.isNotBlank()) append(note.trim())
                                    }.ifBlank { null }

                                    val item = TransactionItem(
                                        id = transactionToEdit?.id ?: "",
                                        categoryId = selectedCategoryId,
                                        walletId = selectedWalletId,
                                        title = title.trim(),
                                        amount = amountNum,
                                        quantity = if (!isIncomeCategory) qtyNum else null,
                                        unit = if (!isIncomeCategory && qtyNum != null) selectedUnit else null,
                                        unitPrice = if (!isIncomeCategory) unitPrice else null,
                                        date = selectedDate,
                                        status = status,
                                        shopOrPerson = if (shopOrPerson.isNotBlank()) shopOrPerson.trim() else null,
                                        note = finalNote,
                                        createdAt = transactionToEdit?.createdAt
                                    )
                                    onSave(item)
                                }
                            }
                        },
                        enabled = if (isTodoMode) title.isNotBlank() else (title.isNotBlank() && amountNum > 0),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(0.58f)
                            .height(48.dp)
                            .testTag("save_transaction_button")
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusOptionButton(
    label: String,
    selected: Boolean,
    activeColor: Color,
    activeBg: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) activeBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) activeColor else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
