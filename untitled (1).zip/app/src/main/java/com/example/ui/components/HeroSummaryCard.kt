package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WalletItem
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GhorkhataInkFaint
import com.example.ui.theme.GhorkhataInkSoft
import com.example.ui.theme.GhorkhataLine
import com.example.util.BnFormat
import kotlin.math.roundToInt

@Composable
fun AppTopBar(
    currentMonth: String,
    showMonthSelector: Boolean,
    showBackButton: Boolean = false,
    screenTitle: String? = null,
    userInitial: String = "G",
    onMenuClick: () -> Unit,
    onBackClick: () -> Unit = {},
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onResetCurrentMonth: () -> Unit,
    onAiClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Top Row: Menu/Back + Brand Logo + AI & Profile buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Menu or Back button
                    Surface(
                        shape = RoundedCornerShape(13.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, GhorkhataLine),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .clickable { if (showBackButton) onBackClick() else onMenuClick() }
                            .testTag("topbar_menu_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (showBackButton) Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.Menu,
                                contentDescription = if (showBackButton) "ফিরে যান" else "মেনু খুলুন",
                                tint = GhorkhataInkSoft,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Logo mark + Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(EmeraldPrimary, EmeraldDeep)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "ঘরখাতা",
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Column {
                            Text(
                                text = screenTitle ?: "ঘরখাতা",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDeep,
                                lineHeight = 22.sp
                            )
                            Text(
                                text = "স্মার্ট খরচ ট্র্যাকার",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = GhorkhataInkFaint,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }

                // Right actions: AI Agent Sparkle button + Profile Avatar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFF10A873), EmeraldDeep)
                                )
                            )
                            .clickable { onAiClick() }
                            .testTag("topbar_ai_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Gemini AI এজেন্ট",
                            tint = Color.White,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFF1A73E8), EmeraldPrimary)
                                )
                            )
                            .border(1.5.dp, Color.White, CircleShape)
                            .clickable { onProfileClick() }
                            .testTag("topbar_profile_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userInitial,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .align(Alignment.BottomEnd)
                                .background(Color(0xFF10A873), CircleShape)
                                .border(1.5.dp, Color.White, CircleShape)
                        )
                    }
                }
            }

            // Month Selector Bar (exact match to .month-nav in ghorkhata.html)
            if (showMonthSelector) {
                Spacer(modifier = Modifier.height(10.dp))
                val isCurrentMonth = currentMonth == BnFormat.currentMonthKey()

                Surface(
                    shape = RoundedCornerShape(15.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, GhorkhataLine),
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .clickable { onPrevMonth() }
                                .testTag("prev_month_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "আগের মাস",
                                tint = GhorkhataInkSoft
                            )
                        }

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(11.dp))
                                .clickable { onResetCurrentMonth() }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = BnFormat.monthLabel(currentMonth),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (isCurrentMonth) {
                                Surface(
                                    shape = RoundedCornerShape(99.dp),
                                    color = EmeraldLight
                                ) {
                                    Text(
                                        text = "চলমান",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0A5C42),
                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(99.dp),
                                    color = Color(0xFFFDF1DF)
                                ) {
                                    Text(
                                        text = "আজ ফিরুন",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmberAccent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .clickable { onNextMonth() }
                                .testTag("next_month_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "পরের মাস",
                                tint = GhorkhataInkSoft
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HeroSummaryCard(
    totalIncome: Double,
    totalExpense: Double,
    txCount: Int
) {
    val netBalance = totalIncome - totalExpense
    val rawRatio = if (totalIncome > 0) (totalExpense / totalIncome).toFloat() else if (totalExpense > 0) 1f else 0f
    val progress = rawRatio.coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "heroProgress")
    val pctInt = if (totalIncome > 0) ((totalExpense / totalIncome) * 100).roundToInt().coerceAtMost(100) else 0

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF0C6B4A), EmeraldDeep)
                    )
                )
        ) {
            // Decorative background circles matching .hero-deco1 and .hero-deco2
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 42.dp, y = (-42).dp)
                    .background(Color.White.copy(alpha = 0.06f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-18).dp, y = 52.dp)
                    .background(Color.White.copy(alpha = 0.045f), CircleShape)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                // Top Row: Balance + Transaction Count Pill Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = "এই মাসের ব্যালেন্স",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = BnFormat.formatTaka(netBalance),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = (-0.5).sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = Color.White.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
                    ) {
                        Text(
                            text = "${BnFormat.toBnDigits(txCount)}টি লেনদেন",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress bar + note
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(99.dp))
                        .background(Color.White.copy(alpha = 0.16f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress)
                            .height(7.dp)
                            .clip(RoundedCornerShape(99.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFFF3B95A), AmberAccent)
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = if (totalIncome > 0) {
                        "আয়ের ${BnFormat.toBnDigits(pctInt)}% খরচ হয়েছে"
                    } else {
                        "এই মাসে এখনো কোনো আয় যোগ হয়নি"
                    },
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.65f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Two-column glassmorphic stats (.hero-stats)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Income Stat Card
                    Surface(
                        shape = RoundedCornerShape(15.dp),
                        color = Color.White.copy(alpha = 0.09f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.13f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF86EFAC).copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "মোট আয়",
                                    tint = Color(0xFF86EFAC),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "মোট আয়",
                                    fontSize = 10.5.sp,
                                    color = Color.White.copy(alpha = 0.68f)
                                )
                                Text(
                                    text = BnFormat.formatTaka(totalIncome),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    // Expense Stat Card
                    Surface(
                        shape = RoundedCornerShape(15.dp),
                        color = Color.White.copy(alpha = 0.09f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.13f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFFDA4AF).copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowDownward,
                                    contentDescription = "মোট খরচ",
                                    tint = Color(0xFFFDA4AF),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "মোট খরচ",
                                    fontSize = 10.5.sp,
                                    color = Color.White.copy(alpha = 0.68f)
                                )
                                Text(
                                    text = BnFormat.formatTaka(totalExpense),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WalletStrip(
    wallets: List<WalletItem>,
    walletBalances: Map<String, Double>,
    onWalletClick: (WalletItem) -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        wallets.forEach { wallet ->
            val balance = (walletBalances[wallet.id] ?: 0.0) + wallet.initialBalance
            val walletColor = IconRegistry.parseColor(wallet.color)

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, GhorkhataLine),
                shadowElevation = 1.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onWalletClick(wallet) }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(walletColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = IconRegistry.getIcon(wallet.icon),
                            contentDescription = wallet.name,
                            tint = walletColor,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Column {
                        Text(
                            text = wallet.name,
                            fontSize = 10.5.sp,
                            color = GhorkhataInkFaint,
                            lineHeight = 12.sp
                        )
                        Text(
                            text = BnFormat.formatTaka(balance),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}
