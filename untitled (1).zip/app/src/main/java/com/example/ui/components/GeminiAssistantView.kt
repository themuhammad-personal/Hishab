package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AgentResponse
import com.example.ai.GeminiAiService
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.repository.GhorkhataRepository
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoseExpense
import com.example.util.BnFormat
import kotlinx.coroutines.launch

data class AgentChatMessage(
    val sender: String, // "user" or "ai"
    val text: String,
    val executedActions: List<String> = emptyList()
)

private data class QuickCard(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val icon: ImageVector,
    val color: Color,
    val bg: Color
)

@Composable
fun GeminiAssistantView(
    repository: GhorkhataRepository,
    currentMonth: String,
    transactions: List<TransactionItem>,
    categories: List<CategoryItem>,
    todos: List<TodoItem>
) {
    var query by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages = remember {
        mutableStateListOf(
            AgentChatMessage(
                sender = "ai",
                text = "আসসালামু আলাইকুম! আমি ঘরখাতা স্মার্ট এআই এজেন্ট। আমি শুধু পরামর্শ দিই না, আপনার নির্দেশে পুরো অ্যাপের খাতা নিয়ন্ত্রণ করতে পারি—\n\n• \"২ কেজি আলু ১২০ টাকা যোগ করো\"\n• \"দোকান বাকি পরিশোধ হয়েছে\"\n• \"বাজারে ডিম ও দুধের ফর্দ লেখো\"\n• অথবা এই মাসের খরচ ও বাজেটের বিশ্লেষণ জানতে যেকোনো প্রশ্ন করুন!"
            )
        )
    }

    val quickActionCards = listOf(
        QuickCard(
            title = "খরচ বিশ্লেষণ",
            subtitle = "চলতি মাসের খরচের অডিট",
            prompt = "চলতি মাসের আয়-ব্যয় এবং প্রধান খরচের খাতগুলো বিস্তারিত বিশ্লেষণ করে আমাকে জানাও।",
            icon = Icons.Default.Receipt,
            color = Color(0xFF0F74A8),
            bg = Color(0xFFE1F0F8)
        ),
        QuickCard(
            title = "সাশ্রয়ের উপায়",
            subtitle = "খরচ কমানোর ৩টি পরামর্শ",
            prompt = "আমার খরচের ধারা দেখে এই মাসে অন্তত ১০-১৫% টাকা কীভাবে বাঁচাব তার বাস্তবসম্মত ৩টি টিপস দাও।",
            icon = Icons.Default.Lightbulb,
            color = Color(0xFFD98324),
            bg = Color(0xFFFEF0DC)
        ),
        QuickCard(
            title = "বাজেট প্ল্যানিং",
            subtitle = "পারিবারিক বাজেটের হিসাব",
            prompt = "আমাদের পরিবারের জন্য বাকি দিনগুলোর খরচ ও জরুরি খাতের জন্য একটি ব্যালেন্সড বাজেট প্রস্তাব করো।",
            icon = Icons.Default.Shield,
            color = Color(0xFF0B8A5F),
            bg = Color(0xFFDDF3E9)
        ),
        QuickCard(
            title = "বাকি ও বিল রিভিউ",
            subtitle = "দোকান বাকি ও মাসিক বিল",
            prompt = "আমার কোন কোন দোকানে বাকি আছে এবং কোন মাসিক বিলগুলো এখনো দেওয়া বাকি তার তালিকা দাও।",
            icon = Icons.Default.TrendingDown,
            color = Color(0xFFD43D51),
            bg = Color(0xFFFDE8EC)
        )
    )

    val quickCommandChips = listOf(
        "➕ ২ কেজি আলু ১২০ টাকা যোগ করো",
        "➕ মফিজ স্টোরে ৫০০ টাকা বাকি লিখে রাখো",
        "📝 বাজারে চিনি ও মসুর ডালের ফর্দ দাও",
        "✓ সব দোকান বাকি পরিশোধ করো"
    )

    fun handleSend(text: String) {
        if (text.isBlank() || isLoading) return
        val userPrompt = text.trim()
        messages.add(AgentChatMessage(sender = "user", text = userPrompt))
        query = ""
        isLoading = true

        scope.launch {
            try {
                val agentResponse: AgentResponse = GeminiAiService.processAgentChat(
                    userMessage = userPrompt,
                    currentMonth = currentMonth,
                    transactions = transactions,
                    categories = categories,
                    todos = todos,
                    repository = repository
                )

                messages.add(
                    AgentChatMessage(
                        sender = "ai",
                        text = agentResponse.replyText,
                        executedActions = agentResponse.executedActions.map { it.summaryBn }
                    )
                )
            } catch (e: Exception) {
                messages.add(
                    AgentChatMessage(
                        sender = "ai",
                        text = "দুঃখিত, তথ্য প্রক্রিয়া করতে সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।"
                    )
                )
            } finally {
                isLoading = false
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("ai_assistant_view")
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. AI Hero Banner (.ai-banner in ghorkhata.html)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(EmeraldDeep, Color(0xFF04382B))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(Color.White.copy(alpha = 0.16f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF6EE7B7),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ঘরখাতা এআই অ্যাকশন এজেন্ট",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "কথা বলুন বা লিখুন—এজেন্ট স্বয়ংক্রিয়ভাবে খাতা আপডেট ও বিশ্লেষণ করবে",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.82f)
                            )
                        }
                    }
                }
            }

            // 2. 2x2 Grid of Preset Action Cards (.ai-prompts-grid in ghorkhata.html)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetCard(card = quickActionCards[0], onClick = { handleSend(quickActionCards[0].prompt) }, modifier = Modifier.weight(1f))
                        PresetCard(card = quickActionCards[1], onClick = { handleSend(quickActionCards[1].prompt) }, modifier = Modifier.weight(1f))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetCard(card = quickActionCards[2], onClick = { handleSend(quickActionCards[2].prompt) }, modifier = Modifier.weight(1f))
                        PresetCard(card = quickActionCards[3], onClick = { handleSend(quickActionCards[3].prompt) }, modifier = Modifier.weight(1f))
                    }
                }
            }

            // 3. Quick Agent Action Command Chips
            item {
                Text(
                    text = "দ্রুত অ্যাকশন কমান্ডসমূহ:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickCommandChips.forEach { chipText ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.22f)),
                            modifier = Modifier.clickable { handleSend(chipText) }
                        ) {
                            Text(
                                text = chipText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
            }

            // 4. Conversation Messages
            items(messages) { msg ->
                val isUser = msg.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        shape = RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isUser) 18.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 18.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUser) EmeraldPrimary else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                        modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.95f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                            )

                            // Action confirmation badges executed by the agent
                            if (msg.executedActions.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    msg.executedActions.forEach { act ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFFDDF3E9),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = EmeraldPrimary,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = act,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "এআই এজেন্ট বিশ্লেষণ ও খাতা আপডেট করছে...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Input Row at bottom
        Surface(
            tonalElevation = 6.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = {
                        Text(
                            "কী যোগ বা জানতে চান লিখুন...",
                            style = MaterialTheme.typography.bodySmall
                        )
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { handleSend(query) },
                    enabled = query.isNotBlank() && !isLoading,
                    modifier = Modifier
                        .size(44.dp)
                        .background(if (query.isNotBlank() && !isLoading) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .testTag("ai_chat_send_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "পাঠান",
                        tint = if (query.isNotBlank() && !isLoading) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PresetCard(
    card: QuickCard,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(card.bg, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = card.icon,
                    contentDescription = null,
                    tint = card.color,
                    modifier = Modifier.size(17.dp)
                )
            }
            Spacer(modifier = Modifier.width(9.dp))
            Column {
                Text(
                    text = card.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontSize = 13.5.sp),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = card.subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
