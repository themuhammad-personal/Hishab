package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalDining
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingBasket
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object IconRegistry {
    fun getIcon(name: String): ImageVector {
        return when (name.lowercase()) {
            "shoppingbasket", "basket", "bazar" -> Icons.Default.ShoppingBasket
            "shoppingbag", "bag" -> Icons.Default.ShoppingBag
            "beef", "meat", "fish", "restaurant" -> Icons.Default.Restaurant
            "home", "house" -> Icons.Default.Home
            "receipt", "monthly", "bill" -> Icons.Default.Receipt
            "store", "dues" -> Icons.Default.Store
            "bus", "transport" -> Icons.Default.DirectionsBus
            "car" -> Icons.Default.DirectionsCar
            "pill", "medical", "hospital" -> Icons.Default.LocalHospital
            "graduationcap", "gradcap", "madrasa", "education" -> Icons.Default.School
            "hearthandshake", "heart", "charity" -> Icons.Default.VolunteerActivism
            "check", "todo", "checklist" -> Icons.Default.Checklist
            "coffee", "snacks", "cafe" -> Icons.Default.LocalCafe
            "fastfood" -> Icons.Default.Fastfood
            "wallet", "cash" -> Icons.Default.LocalAtm
            "trendingup", "income" -> Icons.Default.TrendingUp
            "landmark", "bank" -> Icons.Default.AccountBalance
            "smartphone", "bkash", "nagad", "phone" -> Icons.Default.PhoneAndroid
            "creditcard" -> Icons.Default.CreditCard
            "book" -> Icons.Default.Book
            "dining" -> Icons.Default.LocalDining
            "money" -> Icons.Default.AttachMoney
            "lightbulb", "zap" -> Icons.Default.Lightbulb
            "wrench", "build" -> Icons.Default.Build
            "gift" -> Icons.Default.CardGiftcard
            "wifi" -> Icons.Default.Wifi
            "favorite" -> Icons.Default.Favorite
            "checkcircle" -> Icons.Default.CheckCircle
            else -> Icons.Default.ShoppingBasket
        }
    }

    fun parseColor(hex: String, fallback: Color = Color(0xFF0B8A5F)): Color {
        return try {
            val clean = hex.trim().removePrefix("#")
            val colorLong = clean.toLong(16)
            if (clean.length == 6) {
                Color(0xFF000000 or colorLong)
            } else {
                Color(colorLong)
            }
        } catch (e: Exception) {
            fallback
        }
    }

    fun darkenColor(color: Color, factor: Float = 0.68f): Color {
        return Color(
            red = (color.red * factor).coerceIn(0f, 1f),
            green = (color.green * factor).coerceIn(0f, 1f),
            blue = (color.blue * factor).coerceIn(0f, 1f),
            alpha = color.alpha
        )
    }
}
