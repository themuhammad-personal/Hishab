package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldDeep,
    onPrimaryContainer = EmeraldLight,
    secondary = AmberAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF332008),
    onSecondaryContainer = AmberLight,
    tertiary = SkyBlue,
    background = GhorkhataPaperDark,
    onBackground = Color(0xFFE2E8E4),
    surface = GhorkhataCardDark,
    onSurface = Color(0xFFE2E8E4),
    surfaceVariant = Color(0xFF1E2B25),
    onSurfaceVariant = GhorkhataInkFaint,
    error = RoseExpense,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldLight,
    onPrimaryContainer = EmeraldDeep,
    secondary = AmberAccent,
    onSecondary = Color.White,
    secondaryContainer = AmberLight,
    onSecondaryContainer = Color(0xFF472800),
    tertiary = SkyBlue,
    background = GhorkhataPaper,
    onBackground = GhorkhataInk,
    surface = GhorkhataCard,
    onSurface = GhorkhataInk,
    surfaceVariant = Color(0xFFEDE9DF),
    onSurfaceVariant = GhorkhataInkSoft,
    error = RoseExpense,
    onError = Color.White
)

@Composable
fun GhorkhataTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
