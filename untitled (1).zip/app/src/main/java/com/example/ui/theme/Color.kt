package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Paper & Ink palette from Ghorkhata design guidelines
val GhorkhataPaper = Color(0xFFF6F3EC)
val GhorkhataPaperDark = Color(0xFF0F1512)
val GhorkhataCard = Color(0xFFFFFFFF)
val GhorkhataCardDark = Color(0xFF18221D)

val GhorkhataInk = Color(0xFF1C2420)
val GhorkhataInkSoft = Color(0xFF5C6660)
val GhorkhataInkFaint = Color(0xFF98A29B)
val GhorkhataLine = Color(0x141C2420)

// Vibrant semantic brand colors
val EmeraldPrimary = Color(0xFF0B8A5F)
val EmeraldDeep = Color(0xFF04382B)
val EmeraldLight = Color(0xFFDDF3E9)

val AmberAccent = Color(0xFFD98324)
val AmberLight = Color(0xFFFDF1DF)

val RoseExpense = Color(0xFFD43D51)
val RoseLight = Color(0xFFFDE7EA)

val SkyBlue = Color(0xFF0F74A8)
val SkyLight = Color(0xFFE2F1F8)

val PurpleWallet = Color(0xFF7E3AF2)
val PurpleLight = Color(0xFFF3E8FF)
