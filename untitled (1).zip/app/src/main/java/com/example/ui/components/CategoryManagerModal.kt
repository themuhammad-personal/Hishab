package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CategoryItem
import com.example.ui.theme.RoseExpense

@Composable
fun CategoryManagerModal(
    categories: List<CategoryItem>,
    onDismiss: () -> Unit,
    onSaveCategory: (CategoryItem) -> Unit,
    onDeleteCategory: (String) -> Unit
) {
    var editingCategory by remember { mutableStateOf<CategoryItem?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }

    val iconKeys = listOf("ShoppingBasket", "Beef", "Home", "Store", "Bus", "Pill", "GraduationCap", "HeartHandshake", "Coffee", "Wallet", "TrendingUp")
    val colorKeys = listOf("#0B8A5F", "#D98324", "#D43D51", "#0F74A8", "#7E3AF2", "#10B981", "#E11D48", "#6366F1", "#F59E0B")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ক্যাটাগরি পরিচালনা",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = {
                        editingCategory = CategoryItem(name = "", type = "expense")
                        isCreatingNew = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "New")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("নতুন")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = IconRegistry.getIcon(cat.icon),
                                    contentDescription = cat.name,
                                    tint = IconRegistry.parseColor(cat.color),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = cat.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                if (!cat.isDefault) {
                                    IconButton(onClick = {
                                        editingCategory = cat
                                        isCreatingNew = false
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(onClick = { onDeleteCategory(cat.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = RoseExpense, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("বন্ধ করুন")
                    }
                }
            }
        }
    }

    // Create / Edit Category Subdialog
    if (editingCategory != null) {
        var catName by remember { mutableStateOf(editingCategory?.name ?: "") }
        var selectedIcon by remember { mutableStateOf(editingCategory?.icon ?: "ShoppingBasket") }
        var selectedColor by remember { mutableStateOf(editingCategory?.color ?: "#0B8A5F") }
        var catType by remember { mutableStateOf(editingCategory?.type ?: "expense") }

        Dialog(onDismissRequest = { editingCategory = null }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isCreatingNew) "নতুন ক্যাটাগরি তৈরি" else "ক্যাটাগরি সম্পাদনা",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("ক্যাটাগরির নাম") },
                        placeholder = { Text("যেমন: উপহার ও পোশাক") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("আইকন নির্বাচন:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        iconKeys.forEach { iconName ->
                            FilterChip(
                                selected = selectedIcon == iconName,
                                onClick = { selectedIcon = iconName },
                                leadingIcon = {
                                    Icon(IconRegistry.getIcon(iconName), contentDescription = iconName, modifier = Modifier.size(16.dp))
                                },
                                label = { Text(iconName, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("রং নির্বাচন:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        colorKeys.forEach { colorHex ->
                            FilterChip(
                                selected = selectedColor == colorHex,
                                onClick = { selectedColor = colorHex },
                                label = {
                                    Text(
                                        "■",
                                        color = IconRegistry.parseColor(colorHex),
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        OutlinedButton(onClick = { editingCategory = null }) {
                            Text("বাতিল")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (catName.isNotBlank()) {
                                    val cat = CategoryItem(
                                        id = if (isCreatingNew) "" else (editingCategory?.id ?: ""),
                                        name = catName.trim(),
                                        type = catType,
                                        color = selectedColor,
                                        bgLight = "#F2FAF6",
                                        icon = selectedIcon,
                                        sortOrder = 99,
                                        isDefault = false
                                    )
                                    onSaveCategory(cat)
                                    editingCategory = null
                                }
                            },
                            enabled = catName.isNotBlank()
                        ) {
                            Text("সংরক্ষণ")
                        }
                    }
                }
            }
        }
    }
}
