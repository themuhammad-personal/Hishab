package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.util.BnFormat
import kotlin.math.roundToInt

/**
 * Single Category Card matching `.cat-item` in `ghorkhata.html`.
 */
@Composable
fun CategoryListItemCard(
    category: CategoryItem,
    categoryTransactions: List<TransactionItem>,
    totalMonthExpense: Double,
    todos: List<TodoItem>,
    onClick: () -> Unit
) {
    val catColor = IconRegistry.parseColor(category.color)
    val catBg = IconRegistry.parseColor(category.bgLight)
    val isTodo = category.id == "todo"
    val isIncome = category.type == "income"

    val catTotal = categoryTransactions.sumOf { it.amount }
    val unpaidTotal = categoryTransactions
        .filter { it.status == "baki" || it.status == "pending" }
        .sumOf { it.amount }

    val pct = if (!isIncome && !isTodo && totalMonthExpense > 0 && catTotal > 0) {
        ((catTotal / totalMonthExpense) * 100).roundToInt().coerceIn(1, 100)
    } else 0

    val pendingTodos = todos.count { !it.done }
    val doneTodos = todos.count { it.done }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("cat_card_${category.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 15.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 46dp x 46dp rounded-15dp icon box
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(catBg, RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = IconRegistry.getIcon(category.icon),
                    contentDescription = category.name,
                    tint = catColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(13.dp))

            // Middle Info Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = category.name,
                    style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                if (isTodo) {
                    Text(
                        text = "${BnFormat.toBnDigits(pendingTodos.toString())}টি বাকি · ${BnFormat.toBnDigits(doneTodos.toString())}টি সম্পন্ন",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (categoryTransactions.isNotEmpty())
                                "${BnFormat.toBnDigits(categoryTransactions.size.toString())}টি লেনদেন"
                            else "কোনো লেনদেন নেই",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (unpaidTotal > 0) {
                            Text(
                                text = " · ${BnFormat.formatTaka(unpaidTotal)} বকেয়া",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = AmberAccent
                            )
                        }
                    }
                }

                // Mini Progress Bar (.cat-mini-bar) for Expense Categories
                if (!isIncome && !isTodo && catTotal > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((pct / 100f).coerceIn(0.04f, 1f))
                                .height(4.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(catColor)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Right Amount / Status Column
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isTodo) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (pendingTodos > 0) catBg else Color(0xFFDDF3E9)
                    ) {
                        Text(
                            text = if (pendingTodos > 0)
                                "${BnFormat.toBnDigits(pendingTodos.toString())} বাকি"
                            else "সব শেষ ✓",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (pendingTodos > 0) catColor else EmeraldPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                } else {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = BnFormat.formatTaka(catTotal),
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.5.sp),
                            fontWeight = FontWeight.Bold,
                            color = if (catTotal > 0) catColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                        if (catTotal > 0) {
                            Text(
                                text = if (isIncome) "মোট আয়" else "মোট খরচের ${BnFormat.toBnDigits(pct.toString())}%",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Full Category Detail Screen matching `#cat-detail-page` in `ghorkhata.html`.
 * Features a full-bleed category-colored gradient header, glassmorphic summary card,
 * date-grouped transactions (`tx-date-group`), and bottom inline `+ নতুন যোগ করুন` button.
 */
@Composable
fun CategoryDetailView(
    category: CategoryItem,
    currentMonth: String,
    transactions: List<TransactionItem>,
    todos: List<TodoItem>,
    onBack: () -> Unit,
    onAddClick: (String) -> Unit,
    onTransactionClick: (TransactionItem) -> Unit,
    onStatusToggle: (TransactionItem) -> Unit,
    onDeleteTransaction: (String) -> Unit,
    onAddTodo: (String, Double?, String?, Double?) -> Unit,
    onToggleTodoDone: (TodoItem) -> Unit,
    onDeleteTodo: (String) -> Unit,
    onConvertToExpense: (TodoItem) -> Unit
) {
    val catColor = IconRegistry.parseColor(category.color)
    val darkCatColor = IconRegistry.darkenColor(catColor, 0.28f)
    val isTodo = category.id == "todo"

    val catMonthTransactions = transactions
        .filter { it.categoryId == category.id && BnFormat.monthKey(it.date) == currentMonth }
        .sortedWith(compareByDescending<TransactionItem> { it.date }.thenByDescending { it.createdAt })

    val catTotal = catMonthTransactions.sumOf { it.amount }
    val groupedByDate = catMonthTransactions.groupBy { it.date.ifBlank { BnFormat.currentDateIso() } }

    val pendingTodos = todos.count { !it.done }
    val doneTodos = todos.count { it.done }

    Column(modifier = Modifier.fillMaxSize()) {
        // Full-bleed Colored Gradient Header (.cat-detail-header)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(catColor, darkCatColor)
                    )
                )
        ) {
            // Decorative Circle
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 45.dp, y = (-50).dp)
                    .background(Color.White.copy(alpha = 0.08f), CircleShape)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                // Header Top Row (Back Button + Title + Month Badge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color.White.copy(alpha = 0.16f), CircleShape)
                            .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                            .testTag("cat_detail_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান",
                            tint = Color.White,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = IconRegistry.getIcon(category.icon),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = category.name,
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 19.sp),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = Color.White.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = BnFormat.monthLabel(currentMonth),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.95f),
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Glassmorphic Summary Card (.cat-summary-card)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.13f))
                        .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isTodo) "মোট কাজ" else "এই মাসের মোট ${category.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isTodo)
                                    "${BnFormat.toBnDigits(pendingTodos.toString())}টি বাকি"
                                else BnFormat.formatTaka(catTotal),
                                style = MaterialTheme.typography.headlineMedium.copy(fontSize = 27.sp),
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isTodo)
                                    "মোট ${BnFormat.toBnDigits(todos.size.toString())}টি কাজের মধ্যে ${BnFormat.toBnDigits(doneTodos.toString())}টি সম্পন্ন"
                                else "মোট ${BnFormat.toBnDigits(catMonthTransactions.size.toString())}টি লেনদেন নথিভুক্ত",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.78f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(Color.White.copy(alpha = 0.16f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = IconRegistry.getIcon(category.icon),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        }

        // Body Content
        if (isTodo) {
            TodoMarketListView(
                todos = todos,
                onAddTodo = onAddTodo,
                onToggleDone = onToggleTodoDone,
                onDeleteTodo = onDeleteTodo,
                onConvertToExpense = onConvertToExpense
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 14.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (catMonthTransactions.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .background(
                                            IconRegistry.parseColor(category.bgLight),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        tint = catColor,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "এই মাসে কোনো হিসাব নেই",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${BnFormat.monthLabel(currentMonth)}-এ '${category.name}' খাতায় এখনো কিছু যোগ করা হয়নি।",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    groupedByDate.forEach { (dateIso, dayItems) ->
                        val dayTotal = dayItems.sumOf { it.amount }
                        item(key = "header_$dateIso") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp, bottom = 2.dp, start = 4.dp, end = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = BnFormat.formatBnDateFull(dateIso),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = BnFormat.formatTaka(dayTotal),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        items(dayItems, key = { it.id }) { tx ->
                            TransactionItemRow(
                                transaction = tx,
                                category = category,
                                onClick = { onTransactionClick(tx) },
                                onStatusToggle = { onStatusToggle(tx) },
                                onDelete = { onDeleteTransaction(tx.id) },
                                showCategoryName = false,
                                showDate = false
                            )
                        }
                    }
                }

                // Inline Add Button matching `.add-tx-inline` in ghorkhata.html
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { onAddClick(category.id) },
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.5.dp, catColor.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("cat_detail_add_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = catColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${category.name}-এ নতুন হিসাব যোগ করুন",
                            fontWeight = FontWeight.Bold,
                            color = catColor
                        )
                    }
                }
            }
        }
    }
}
