package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryItem
import com.example.data.model.TodoItem
import com.example.data.model.TransactionItem
import com.example.data.model.WalletItem
import com.example.ui.theme.EmeraldPrimary
import com.example.util.BnFormat

@Composable
fun HomeDashboardView(
    currentMonth: String,
    transactions: List<TransactionItem>,
    categories: List<CategoryItem>,
    wallets: List<WalletItem>,
    todos: List<TodoItem>,
    onCategoryClick: (CategoryItem) -> Unit,
    onTransactionClick: (TransactionItem) -> Unit,
    onStatusToggle: (TransactionItem) -> Unit,
    onDeleteTransaction: (String) -> Unit,
    onOpenReports: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val monthTransactions = remember(transactions, currentMonth) {
        transactions.filter { BnFormat.monthKey(it.date) == currentMonth }
    }

    val totalIncome = remember(monthTransactions, categories) {
        monthTransactions.filter { tx ->
            val cat = categories.find { it.id == tx.categoryId }
            cat?.type == "income" || tx.categoryId == "income"
        }.sumOf { it.amount }
    }

    val totalExpense = remember(monthTransactions, categories) {
        monthTransactions.filter { tx ->
            val cat = categories.find { it.id == tx.categoryId }
            cat?.type != "income" && tx.categoryId != "income"
        }.sumOf { it.amount }
    }

    // Calculate wallet balances across all transactions
    val walletBalances = remember(transactions, categories) {
        val map = mutableMapOf<String, Double>()
        for (tx in transactions) {
            val cat = categories.find { it.id == tx.categoryId }
            val isIncome = cat?.type == "income" || tx.categoryId == "income"
            val current = map[tx.walletId] ?: 0.0
            if (isIncome) {
                map[tx.walletId] = current + tx.amount
            } else if (tx.status == "paid") {
                map[tx.walletId] = current - tx.amount
            }
        }
        map
    }

    val sortedCategories = remember(categories) {
        categories.sortedBy { it.sortOrder }
    }

    val searchResults = remember(monthTransactions, searchQuery, categories) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim()
            monthTransactions.filter { tx ->
                val catName = categories.find { it.id == tx.categoryId }?.name ?: ""
                tx.title.contains(q, ignoreCase = true) ||
                    catName.contains(q, ignoreCase = true) ||
                    (tx.note?.contains(q, ignoreCase = true) == true) ||
                    (tx.shopOrPerson?.contains(q, ignoreCase = true) == true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Hero Summary Card (matches ghorkhata.html .hero-card, NO duplicate + button)
        item {
            HeroSummaryCard(
                totalIncome = totalIncome,
                totalExpense = totalExpense,
                txCount = monthTransactions.size
            )
        }

        // 2. Wallet Strip (Cash, bKash, Nagad, Bank)
        if (wallets.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(2.dp))
                WalletStrip(
                    wallets = wallets,
                    walletBalances = walletBalances
                )
            }
        }

        // 3. Compact Search Bar
        item {
            Spacer(modifier = Modifier.height(2.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        "খাতা বা লেনদেন খুঁজুন (যেমন: চাল, বিদ্যুৎ বিল, মফিজ স্টোর)...",
                        style = MaterialTheme.typography.bodySmall
                    )
                },
                leadingIcon = {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = "খুঁজুন",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(19.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "মুছুন",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(15.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.22f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input"),
                singleLine = true
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                Text(
                    text = "অনুসন্ধানের ফলাফল (${BnFormat.toBnDigits(searchResults.size.toString())}টি)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (searchResults.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "'$searchQuery' দিয়ে এই মাসে কোনো লেনদেন পাওয়া যায়নি।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(searchResults, key = { it.id }) { tx ->
                    val cat = categories.find { it.id == tx.categoryId }
                    TransactionItemRow(
                        transaction = tx,
                        category = cat,
                        onClick = { onTransactionClick(tx) },
                        onStatusToggle = { onStatusToggle(tx) },
                        onDelete = { onDeleteTransaction(tx.id) },
                        showCategoryName = true,
                        showDate = true
                    )
                }
            }
        } else {
            // 4. Section Header: "খাতাসমূহ" + "সব দেখুন / রিপোর্ট →"
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "খাতাসমূহ",
                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onOpenReports() }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                            .testTag("home_open_reports_btn")
                    ) {
                        Text(
                            text = "সব দেখুন / রিপোর্ট",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // 5. Category List Cards (.cat-list in ghorkhata.html)
            items(sortedCategories, key = { it.id }) { category ->
                val catTxs = monthTransactions.filter { it.categoryId == category.id }
                CategoryListItemCard(
                    category = category,
                    categoryTransactions = catTxs,
                    totalMonthExpense = totalExpense,
                    todos = todos,
                    onClick = { onCategoryClick(category) }
                )
            }
        }
    }
}
