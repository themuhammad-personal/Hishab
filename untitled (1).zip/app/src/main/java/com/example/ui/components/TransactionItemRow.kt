package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CategoryItem
import com.example.data.model.TransactionItem
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoseExpense
import com.example.util.BnFormat

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransactionItemRow(
    transaction: TransactionItem,
    category: CategoryItem?,
    onClick: () -> Unit,
    onStatusToggle: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    showCategoryName: Boolean = true,
    showDate: Boolean = false
) {
    val isIncome = category?.type == "income"
    val catColor = IconRegistry.parseColor(category?.color ?: "#0B8A5F")
    val catBg = IconRegistry.parseColor(category?.bgLight ?: "#DDF3E9")

    val statusInfo = when (transaction.status) {
        "baki" -> Triple("বাকি", RoseExpense, Color(0xFFFDE8EC))
        "pending" -> Triple("অপেক্ষমান", AmberAccent, Color(0xFFFEF0DC))
        else -> Triple(if (isIncome) "প্রাপ্ত" else "পরিশোধিত", EmeraldPrimary, Color(0xFFDDF3E9))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("tx_row_${transaction.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Icon Box (42dp rounded-13dp matching ghorkhata.html .tx-icon)
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(catBg, RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = IconRegistry.getIcon(category?.icon ?: "ShoppingBasket"),
                    contentDescription = category?.name ?: "খাতা",
                    tint = catColor,
                    modifier = Modifier.size(21.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Status Badge (Clickable to toggle Paid/Unpaid if onStatusToggle provided)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = statusInfo.third,
                        modifier = if (onStatusToggle != null) {
                            Modifier.clickable { onStatusToggle() }
                        } else Modifier
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = statusInfo.first,
                                style = MaterialTheme.typography.labelSmall,
                                color = statusInfo.second,
                                fontWeight = FontWeight.Bold
                            )
                            if (transaction.status != "paid" && onStatusToggle != null) {
                                Spacer(modifier = Modifier.width(3.dp))
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "পরিশোধ করুন",
                                    tint = statusInfo.second,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }

                    // Quantity + Unit Badge
                    if (transaction.quantity != null && transaction.quantity > 0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = BnFormat.formatQuantity(transaction.quantity, transaction.unit),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Unit Price Badge
                    if (transaction.unitPrice != null && transaction.unitPrice > 0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                        ) {
                            Text(
                                text = "দর: ${BnFormat.formatTaka(transaction.unitPrice)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Shop or Person Badge
                    if (!transaction.shopOrPerson.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF0DC)
                        ) {
                            Text(
                                text = transaction.shopOrPerson,
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberAccent,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (showCategoryName && category != null) {
                        Text(
                            text = "• ${category.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }

                    if (showDate && transaction.date.isNotBlank()) {
                        Text(
                            text = "• ${BnFormat.formatBnDate(transaction.date)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }

                // Note / Comment line (Restored from ghorkhata.html .tx-note)
                if (!transaction.note.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "📝 ${transaction.note}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Right Side: Amount + Quick Edit/Delete
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = BnFormat.formatTaka(transaction.amount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isIncome) EmeraldPrimary else catColor
                )

                if (onDelete != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                .clickable { onClick() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "সম্পাদনা",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color(0xFFFDE8EC), CircleShape)
                                .clickable { onDelete() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "মুছে ফেলুন",
                                tint = RoseExpense,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
