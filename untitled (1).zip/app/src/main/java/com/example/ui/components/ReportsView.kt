package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryItem
import com.example.data.model.TransactionItem
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoseExpense
import com.example.util.BnFormat
import kotlin.math.abs
import kotlin.math.roundToInt

private data class CategoryReportStat(
    val category: CategoryItem,
    val total: Double,
    val count: Int,
    val pct: Int
)

@Composable
fun ReportsView(
    currentMonth: String,
    transactions: List<TransactionItem>,
    categories: List<CategoryItem>,
    onCategoryClick: (CategoryItem) -> Unit = {},
    onTransactionClick: (TransactionItem) -> Unit = {}
) {
    val monthTransactions = remember(transactions, currentMonth) {
        transactions.filter { BnFormat.monthKey(it.date) == currentMonth }
    }

    val totalIncome = remember(monthTransactions, categories) {
        monthTransactions.filter { tx ->
            val cat = categories.find { it.id == tx.categoryId }
            cat?.type == "income" || tx.categoryId == "income"
        }.sumOf { it.amount }
    }

    val expenseTransactions = remember(monthTransactions, categories) {
        monthTransactions.filter { tx ->
            val cat = categories.find { it.id == tx.categoryId }
            cat?.type != "income" && tx.categoryId != "income"
        }
    }

    val totalExpense = remember(expenseTransactions) {
        expenseTransactions.sumOf { it.amount }
    }

    val netBalance = totalIncome - totalExpense
    val savePct = if (totalIncome > 0 && netBalance >= 0) {
        ((netBalance / totalIncome) * 100).roundToInt()
    } else 0

    // Category Breakdown Stats
    val categoryStats = remember(expenseTransactions, categories, totalExpense) {
        categories
            .filter { it.type != "income" && it.id != "todo" }
            .mapNotNull { cat ->
                val txs = expenseTransactions.filter { it.categoryId == cat.id }
                val sum = txs.sumOf { it.amount }
                if (sum > 0) {
                    val pct = if (totalExpense > 0) ((sum / totalExpense) * 100).roundToInt().coerceAtLeast(1) else 0
                    CategoryReportStat(cat, sum, txs.size, pct)
                } else null
            }
            .sortedByDescending { it.total }
    }

    // Daily Spending Map (1..daysInMonth)
    val daysCount = remember(currentMonth) { BnFormat.daysInMonth(currentMonth) }
    val dailyTotals = remember(expenseTransactions, daysCount) {
        val arr = DoubleArray(daysCount + 1)
        expenseTransactions.forEach { tx ->
            val day = tx.date.split("-").getOrNull(2)?.toIntOrNull()
            if (day != null && day in 1..daysCount) {
                arr[day] += tx.amount
            }
        }
        arr
    }
    val maxDaySpend = remember(dailyTotals) {
        (dailyTotals.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    }

    var selectedDay by remember(currentMonth, dailyTotals) {
        val peakDay = (1..daysCount).maxByOrNull { dailyTotals[it] } ?: 1
        mutableStateOf(if (dailyTotals[peakDay] > 0) peakDay else null)
    }

    // Top 5 Individual Expenses
    val topExpenses = remember(expenseTransactions) {
        expenseTransactions.sortedByDescending { it.amount }.take(5)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("reports_view"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Report Hero Card (.report-hero in ghorkhata.html)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = "নিট ব্যালেন্স · ${BnFormat.monthLabel(currentMonth)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.72f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${if (netBalance < 0) "-" else ""}${BnFormat.formatTaka(abs(netBalance))}",
                        style = MaterialTheme.typography.headlineLarge.copy(fontSize = 30.sp),
                        fontWeight = FontWeight.Bold,
                        color = if (netBalance >= 0) Color(0xFF6EE7B7) else Color(0xFFFCA5A5)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when {
                            totalIncome > 0 && netBalance >= 0 ->
                                "আলহামদুলিল্লাহ! আয়ের ${BnFormat.toBnDigits(savePct.toString())}% সঞ্চয় হয়েছে"
                            netBalance < 0 ->
                                "সতর্কতা: আয়ের চেয়ে খরচ বেশি হয়েছে"
                            else ->
                                "এই মাসের আয় ও ব্যয়ের সারসংক্ষেপ"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.78f)
                    )
                }
            }
        }

        // 2. Two-Column Income vs Expense Cards (.report-summary-grid)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color(0xFFDDF3E9), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "মোট আয়",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = BnFormat.formatTaka(totalIncome),
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color(0xFFFDE8EC), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = null,
                                tint = RoseExpense,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "মোট খরচ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = BnFormat.formatTaka(totalExpense),
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                            fontWeight = FontWeight.Bold,
                            color = RoseExpense
                        )
                    }
                }
            }
        }

        // 3. Chart Card 1: Multi-Segment Donut Chart & Category Breakdown ("খাতা অনুযায়ী খরচ")
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "খাতা অনুযায়ী খরচ",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (categoryStats.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "এই মাসে কোনো খরচের তথ্য নেই",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        // Donut Chart + Top 5 Legend Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            // Compose Multi-Segment Donut Canvas
                            Box(
                                modifier = Modifier.size(136.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val trackColor = MaterialTheme.colorScheme.surfaceVariant
                                Canvas(modifier = Modifier.size(124.dp)) {
                                    val strokeWidth = 22.dp.toPx()
                                    val diameter = size.minDimension - strokeWidth
                                    val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                                    val arcSize = Size(diameter, diameter)

                                    drawArc(
                                        color = trackColor,
                                        startAngle = 0f,
                                        sweepAngle = 360f,
                                        useCenter = false,
                                        topLeft = topLeft,
                                        size = arcSize,
                                        style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                    )

                                    var startAngle = -90f
                                    categoryStats.forEach { stat ->
                                        val sweep = if (totalExpense > 0) {
                                            ((stat.total / totalExpense) * 360f).toFloat()
                                        } else 0f
                                        if (sweep > 0.5f) {
                                            drawArc(
                                                color = IconRegistry.parseColor(stat.category.color),
                                                startAngle = startAngle,
                                                sweepAngle = (sweep - 1.5f).coerceAtLeast(1f),
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = arcSize,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                            )
                                            startAngle += sweep
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "মোট খরচ",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = BnFormat.formatTaka(totalExpense),
                                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            // Legend (Top 5)
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                categoryStats.take(5).forEach { stat ->
                                    val catColor = IconRegistry.parseColor(stat.category.color)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onCategoryClick(stat.category) },
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(10.dp)
                                                    .background(catColor, RoundedCornerShape(3.dp))
                                            )
                                            Spacer(modifier = Modifier.width(7.dp))
                                            Text(
                                                text = stat.category.name,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${BnFormat.toBnDigits(stat.pct.toString())}%",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Category Breakdown Progress Bars (.cat-bar-list)
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            categoryStats.forEach { stat ->
                                val catColor = IconRegistry.parseColor(stat.category.color)
                                val catBg = IconRegistry.parseColor(stat.category.bgLight)
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { onCategoryClick(stat.category) }
                                        .padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(30.dp)
                                                    .background(catBg, RoundedCornerShape(9.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = IconRegistry.getIcon(stat.category.icon),
                                                    contentDescription = null,
                                                    tint = catColor,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = stat.category.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "(${BnFormat.toBnDigits(stat.count.toString())}টি)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = BnFormat.formatTaka(stat.total),
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = catColor
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${BnFormat.toBnDigits(stat.pct.toString())}%",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(7.dp)
                                            .clip(RoundedCornerShape(99.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth((stat.pct / 100f).coerceIn(0.03f, 1f))
                                                .height(7.dp)
                                                .clip(RoundedCornerShape(99.dp))
                                                .background(catColor)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Chart Card 2: Daily Spending Bar Chart ("দৈনিক খরচ")
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "দৈনিক খরচ (${BnFormat.monthLabel(currentMonth)})",
                                style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (selectedDay != null) {
                            val d = selectedDay!!
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFDDF3E9)
                            ) {
                                Text(
                                    text = "${BnFormat.toBnDigits(d.toString())} তারিখ: ${BnFormat.formatTaka(dailyTotals[d])}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Interactive Daily Bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(116.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        for (day in 1..daysCount) {
                            val amt = dailyTotals[day]
                            val heightFraction = if (amt > 0) {
                                ((amt / maxDaySpend).toFloat()).coerceIn(0.10f, 1f)
                            } else 0.04f
                            val isSelected = selectedDay == day

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clickable { selectedDay = day },
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(heightFraction)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(
                                            when {
                                                isSelected -> AmberAccent
                                                amt > 0 -> EmeraldPrimary
                                                else -> MaterialTheme.colorScheme.surfaceVariant
                                            }
                                        )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Axis Labels
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(1, 7, 14, 21, daysCount).forEach { d ->
                            Text(
                                text = BnFormat.toBnDigits(d.toString()),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 5. Chart Card 3: Top 5 Highest Expenses ("সর্বোচ্চ খরচ (টপ ৫)")
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = AmberAccent,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "সর্বোচ্চ খরচ (টপ ৫)",
                            style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (topExpenses.isEmpty()) {
                        Text(
                            text = "এই মাসে কোনো খরচের তথ্য নেই",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            topExpenses.forEachIndexed { index, tx ->
                                val cat = categories.find { it.id == tx.categoryId }
                                val catColor = IconRegistry.parseColor(cat?.color ?: "#0B8A5F")
                                val isTopOne = index == 0

                                Surface(
                                    shape = RoundedCornerShape(13.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onTransactionClick(tx) }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(26.dp)
                                                .background(
                                                    if (isTopOne) Color(0xFFFEF0DC) else MaterialTheme.colorScheme.surface,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = BnFormat.toBnDigits((index + 1).toString()),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isTopOne) AmberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = tx.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${cat?.name ?: "অন্যান্য"} · ${BnFormat.formatBnDate(tx.date)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Text(
                                            text = BnFormat.formatTaka(tx.amount),
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = catColor
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Smart Tip Card ("পরামর্শ")
        item {
            val topCatStat = categoryStats.firstOrNull()
            val tipMessage = if (topCatStat != null) {
                "এই মাসে আপনার সবচেয়ে বেশি খরচ হয়েছে '${topCatStat.category.name}' খাতে (${BnFormat.formatTaka(topCatStat.total)}, মোট খরচের ${BnFormat.toBnDigits(topCatStat.pct.toString())}%)। অপ্রয়োজনীয় খরচ কমাতে প্রতি সপ্তাহে অন্তত একবার এই রিপোর্টটি পর্যালোচনা করুন।"
            } else {
                "নিয়মিত প্রতিদিনের বাজার ও বিলের হিসাব লিখে রাখলে মাসের শেষে সহজেই সঞ্চয়ের খাতগুলো চিহ্নিত করতে পারবেন।"
            }

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFFDCFCE7), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFF15803D),
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "পরামর্শ",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14532D)
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = tipMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF166534)
                        )
                    }
                }
            }
        }
    }
}
