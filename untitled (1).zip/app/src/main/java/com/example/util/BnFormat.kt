package com.example.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object BnFormat {
    private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    private val enDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

    val bnMonths = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    fun toBnDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            val idx = ch - '0'
            if (idx in 0..9) {
                sb.append(bnDigits[idx])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toBnDigits(number: Int): String = toBnDigits(number.toString())
    fun toBnDigits(number: Long): String = toBnDigits(number.toString())

    fun toEnDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            val idx = bnDigits.indexOf(ch)
            if (idx != -1) {
                sb.append(enDigits[idx])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatTaka(amount: Double, useBengali: Boolean = true): String {
        val sign = if (amount < 0) "−" else ""
        val absVal = abs(amount)
        val formatter = DecimalFormat("#,##,##0.##")
        val formatted = formatter.format(absVal)
        return if (useBengali) {
            "$sign৳${toBnDigits(formatted)}"
        } else {
            "$sign৳$formatted"
        }
    }

    fun formatQuantity(qty: Double?, unit: String?, useBengali: Boolean = true): String {
        if (qty == null || qty <= 0.0) return ""
        val qtyStr = if (qty % 1.0 == 0.0) qty.toLong().toString() else qty.toString()
        val num = if (useBengali) toBnDigits(qtyStr) else qtyStr
        return if (!unit.isNullOrBlank()) "$num $unit" else num
    }

    fun currentDateIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun yesterdayDateIso(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_MONTH, -1)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(cal.time)
    }

    fun currentMonthKey(): String {
        return currentDateIso().take(7) // YYYY-MM
    }

    fun monthKey(dateIso: String): String {
        return if (dateIso.length >= 7) dateIso.take(7) else currentMonthKey()
    }

    fun monthLabel(monthKey: String): String {
        val parts = monthKey.split("-")
        if (parts.size < 2) return monthKey
        val year = parts[0]
        val monthIdx = (parts[1].toIntOrNull() ?: 1).coerceIn(1, 12) - 1
        return "${bnMonths[monthIdx]} ${toBnDigits(year)}"
    }

    fun shiftMonthKey(monthKey: String, deltaMonths: Int): String {
        val parts = monthKey.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val month = parts.getOrNull(1)?.toIntOrNull() ?: 1
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, deltaMonths)
        val newY = cal.get(Calendar.YEAR)
        val newM = cal.get(Calendar.MONTH) + 1
        return String.format(Locale.US, "%04d-%02d", newY, newM)
    }

    fun daysInMonth(monthKey: String): Int {
        val parts = monthKey.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val month = parts.getOrNull(1)?.toIntOrNull() ?: 1
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun formatBnDate(dateIso: String): String {
        val parts = dateIso.split("-")
        if (parts.size < 3) return dateIso
        val monthIdx = (parts[1].toIntOrNull() ?: 1).coerceIn(1, 12) - 1
        val day = parts[2].toIntOrNull() ?: 1
        return "${toBnDigits(day)} ${bnMonths[monthIdx]}"
    }

    fun formatBnDateFull(dateIso: String): String {
        val parts = dateIso.split("-")
        if (parts.size < 3) return dateIso
        val year = parts[0]
        val monthIdx = (parts[1].toIntOrNull() ?: 1).coerceIn(1, 12) - 1
        val day = parts[2].toIntOrNull() ?: 1
        val today = currentDateIso()
        val yesterday = yesterdayDateIso()
        val prefix = when (dateIso) {
            today -> "আজ, "
            yesterday -> "গতকাল, "
            else -> ""
        }
        return "$prefix${toBnDigits(day)} ${bnMonths[monthIdx]} ${toBnDigits(year)}"
    }

    fun currentMonthNameBn(): String {
        return monthLabel(currentMonthKey())
    }
}
