const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;

before(async () => {
  const rules = fs.readFileSync("firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: "gen-lang-client-0063798995",
    firestore: {
      host: "127.0.0.1",
      port: 8085,
      rules: rules
    }
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("unauthenticated user cannot read transactions", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthedDb.collection("users").doc("user_123").collection("transactions").get());
});

test("authenticated user can read and write their own transactions", async () => {
  const authedDb = testEnv.authenticatedContext("user_123").firestore();
  const docRef = authedDb.collection("users").doc("user_123").collection("transactions").doc("tx_1");
  await assertSucceeds(docRef.set({
    userId: "user_123",
    title: "বাজার সদাই",
    amount: 500,
    createdAt: new Date(),
    updatedAt: new Date()
  }));
});

test("user cannot read another user's transactions", async () => {
  const aliceDb = testEnv.authenticatedContext("alice").firestore();
  await assertFails(aliceDb.collection("users").doc("bob").collection("transactions").get());
});
